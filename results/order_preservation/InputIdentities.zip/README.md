# Portable exact-input acquisition manifest v3

This is a local, sanitized delivery candidate, not a public release. No downloads,
models, GPU work, terms acceptance, credentials or rights decisions are performed
by the validator. Previous v2 artifacts are immutable.

## Files for a reader

- `InputAcquisitionManifest_v3.json`: exact cohorts, labels, class/candidate
  reconstruction, input fingerprints, pinned mirror members and extraction rules.
- `validate_inputs_v3.py`: standalone offline validator; does not depend on this
  workspace, its parent directory, HF credentials, or the cache evidence files.
- `test_portable_v3.py`: CPU structure, sanitization and tampering regression tests.
- `RuntimeRequirements.json`: observed CPU dependencies, not an installer.

The manifest SHA256 is:

```text
65c5676006966205a058f43e46e05e52ab9b2c112af2bd218c72056b3e74ec92
```

The fingerprint must be supplied separately when validating; do not silently
compute and trust a replacement manifest received with untrusted inputs.

## Source identities and limits

| Dataset | Repository / revision | Evidence level |
| --- | --- | --- |
| CIFAR100 | `uoft-cs/cifar100` / `aadb3af77e9048adbea6b47c21a81e47dd092ae5` | Local repository-named ref, retained inventory, revision tree, per-member metadata, complete locked-member SHA256 and README Git blob |
| ImageNet mirror | `mrm8488/ImageNet1K-val` / `f004a913f9170e5ff39e63f6172ee3ae918197c9` | Same local evidence chain for all 14 members; not official filename authentication |
| Food101 | `ethz/food101` / `83488de741c1bd1ce27aa6a2b33e19c7bdf92ca9` | Recorded source-lock identity only; no newly authenticated repository cache chain |

Local authentication means correspondence of retained repository/cache evidence
and exact locked bytes. It is not a publisher signature, current external
availability test, official-original-content crosscheck, legal opinion or
permission to redistribute images, captions, derivatives, tokens or model states.
The manifest explicitly keeps these claims false or unestablished. No official
CIFAR archive download is needed to validate the original matching parquets.

## Lawfully obtained input layout

Obtain matching assets independently and lawfully. Each pinned mirror asset has
its `repository_member`, revision-specific `retrieval_url`, exact SHA256 and byte
count. URLs are acquisition locators, not claims of currently verified access.
No automatic downloader is included.

For CIFAR100, point `--asset-root` at the directory containing the two parquet
basenames (the repository's `cifar100` subdirectory). For ImageNet, point it at the
repository root containing `data/`, `README.md` and `dataset_infos.json`. Metadata
SHA256 fingerprints are retained in `metadata_assets`; the source mirror WNID
ordering is not an authenticated official ImageNet filename crosswalk.

Every selected row supplies `source_asset`, zero-based `source_row`, role and
ordered `position`, original source label, encoded-image hash, RGB-pixel hash,
and stable identity. Locate rows in physical parquet order without presorting.
Decode embedded image bytes, convert to RGB using Pillow without EXIF transpose.
Pixel SHA256 includes ASCII `RGB:width:height:` before the row-major RGB bytes.
The exact class-name transformation, prompt template (including punctuation),
class order and candidate UTF-8 hashes permit text reconstruction without model
weights. Do not replace this template with templates from another campaign.
No raw caption strings or token buffers are included. Existing Flickr annotation
fingerprints and named Karpathy split metadata remain unchanged; they do not
grant permission or assert that the named split is an official dataset-creator
split.

## Offline commands

From a directory containing the portable reader files:

```powershell
$fingerprint = '65c5676006966205a058f43e46e05e52ab9b2c112af2bd218c72056b3e74ec92'
python -B -I validate_inputs_v3.py --manifest-sha256 $fingerprint
python -B -I validate_inputs_v3.py --manifest-sha256 $fingerprint --dataset cifar100 --asset-root '<lawfully-obtained-cifar100-directory>'
python -B -I validate_inputs_v3.py --manifest-sha256 $fingerprint --dataset imagenet --asset-root '<lawfully-obtained-imagenet-mirror-root>'
python -B -m unittest discover -s . -p test_portable_v3.py
```

Structure validation alone is not an acquired-input check. Dataset checks read
all source members for SHA256 and compare the selected records, labels, encoded
bytes and RGB fingerprints; they do not write or substitute scientific inputs.

## Derivation and verification

`prepare_v3.py` records the local derivation from immutable v2 and fresh local
source-recovery evidence. It is not required in the portable reader package.
All prior cohort rows are preserved exactly. The derivative also fixes inherited
loop-variable shadowing in manifest validation so that ImageNet WNID and Flickr
candidate/split checks cannot be skipped by a class-name loop; there is a targeted
regression test. This is a validator correction, not a data or science change.

`Verification.json` records isolated standalone CPU tests and actual local input
checks. The portable package excludes that internal preparation script, private
cache inventories, images, captions, weights and token/reference buffers.
`Delivery.json` and `Manifest.json` provide the final delivery inventory and
protected-v2 checks. No push, tag, release or DOI is authorized by this preparation.
