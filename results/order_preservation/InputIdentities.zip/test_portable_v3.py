import copy
import json
from pathlib import Path
import unittest
from validate_inputs_v3 import validate_manifest

HERE = Path(__file__).resolve().parent


class PortableV3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads((HERE/'InputAcquisitionManifest_v3.json').read_text())

    def test_complete_inventory(self):
        self.assertEqual(validate_manifest(self.manifest), 19448)

    def test_missing_repository(self):
        for name in ['cifar100', 'imagenet']:
            d = copy.deepcopy(self.manifest)
            del d['datasets'][name]['repository_id']
            with self.assertRaises(ValueError):
                validate_manifest(d)

    def test_mutated_member_hash(self):
        for name in ['cifar100', 'imagenet']:
            d = copy.deepcopy(self.manifest)
            d['datasets'][name]['source_assets'][0]['sha256'] = '0'*64
            with self.assertRaises(ValueError):
                validate_manifest(d)

    def test_revision_and_member_mutation(self):
        for field, value in [('source_revision', '0'*40), ('repository_id', 'other/repo')]:
            d = copy.deepcopy(self.manifest)
            d['datasets']['cifar100'][field] = value
            with self.assertRaises(ValueError):
                validate_manifest(d)
        d = copy.deepcopy(self.manifest)
        d['datasets']['imagenet']['source_assets'][0]['repository_member'] = '../escape'
        with self.assertRaises(ValueError):
            validate_manifest(d)

    def test_sanitization(self):
        for value in ['Z:/forbidden/example', '/home/example/private', '\\\\example\\share']:
            d = copy.deepcopy(self.manifest); d['extra_note'] = value
            with self.assertRaises(ValueError):
                validate_manifest(d)
        for key in ['captions', 'input_ids', 'pixel_values', 'access_token', 'reference_buffers']:
            d = copy.deepcopy(self.manifest); d[key] = 'forbidden'
            with self.assertRaises(ValueError):
                validate_manifest(d)

    def test_access_and_rights_are_not_upgraded(self):
        for key in ['current_external_availability_verified', 'official_rights_authenticated']:
            d = copy.deepcopy(self.manifest)
            d['datasets']['cifar100']['acquisition_evidence'][key] = True
            with self.assertRaises(ValueError):
                validate_manifest(d)

    def test_imagenet_wnid_check_not_shadowed_by_prompt_name(self):
        d = copy.deepcopy(self.manifest)
        d['datasets']['imagenet']['splits']['transfer'][0]['wnid'] = 'n00000000'
        with self.assertRaises(ValueError):
            validate_manifest(d)

    def test_candidate_and_row_metadata_are_bound(self):
        d = copy.deepcopy(self.manifest)
        d['datasets']['cifar100']['classes'][0]['candidate_utf8_sha256'] = '0'*64
        with self.assertRaises(ValueError):
            validate_manifest(d)

    def test_food101_claim_remains_recorded_only(self):
        for key in ['repository_cache_chain_authenticated', 'current_external_availability_verified', 'official_rights_authenticated']:
            d = copy.deepcopy(self.manifest)
            d['datasets']['food101']['acquisition_evidence'][key] = True
            with self.assertRaises(ValueError):
                validate_manifest(d)
        d = copy.deepcopy(self.manifest)
        d['datasets']['cifar100']['splits']['calibration'][0]['position'] = 1
        with self.assertRaises(ValueError):
            validate_manifest(d)


if __name__ == '__main__':
    unittest.main()
