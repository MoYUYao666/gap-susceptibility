"""Offline, fail-closed checks of lawfully acquired exact A1 input identities.

No network, terms acceptance, dataset extraction, model or inference operations.
Reports go to stdout only. Read-only roots are supplied explicitly by the reader.
"""
import argparse
from collections import defaultdict
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile


def require(value, message):
    if not value: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4*1024*1024), b''): h.update(block)
    return h.hexdigest()


def safe_relative(value):
    require(isinstance(value, str) and bool(value), 'Empty locator')
    require('\\' not in value and ':' not in value and not value.startswith('/'), 'Nonportable locator')
    require('..' not in PurePosixPath(value).parts, 'Traversal locator')
    return value


def inside(root, relative):
    root = Path(root).resolve(); p = (root/safe_relative(relative)).resolve()
    require(p.is_relative_to(root), 'Resolved locator escapes reader root')
    return p


def _validate_structure(doc):
    banned = {'caption', 'captions', 'effective_texts', 'input_ids', 'pixel_values', 'path', 'input_path'}
    def walk(v):
        if isinstance(v, dict):
            require(not (set(v) & banned), 'Raw input or host-path field in sanitized manifest')
            for x in v.values(): walk(x)
        elif isinstance(v, list):
            for x in v: walk(x)
        elif isinstance(v, str):
            require(not re.search(r'(?i)((?<![a-z])[a-z]:[/\\]|\\\\)', v), 'Machine path in sanitized manifest')
    walk(doc)
    require(doc.get('schema_version') == 3 and bool(doc.get('datasets')), 'Missing dataset inventory')
    n = 0
    for name, data in doc['datasets'].items():
        classes = data.get('classes')
        if classes:
            require([c['index'] for c in classes] == list(range(len(classes))), 'Class order mismatch')
            if 'prompt_template' in data:
                mode=data.get('class_name_text_transform')
                require(mode in ['identity','replace_ascii_underscore_with_space'],'Missing explicit prompt reconstruction rule')
                for c in classes:
                    class_name=c['name'] if mode=='identity' else c['name'].replace('_',' ')
                    require(sha(data['prompt_template'].format(class_name).encode())==c['candidate_utf8_sha256'], 'Candidate prompt mismatch')
        all_ids = set()
        for split, rows in data['splits'].items():
            require(bool(rows), 'Empty declared cohort')
            require([r['position'] for r in rows] == list(range(len(rows))), 'Row order mismatch')
            for r in rows:
                sid = r['stable_id']
                require(sid not in all_ids, 'Repeated source ID within dataset roles')
                all_ids.add(sid)
                require(sha(sid.encode()) == r['stable_id_utf8_sha256'], 'Stable ID mismatch')
                require(type(r['label']) is int and 0 <= r['label'] < (len(classes) if classes else len(rows)), 'Label range mismatch')
                for key in ['image_sha256', 'pixel_sha256']:
                    require(bool(re.fullmatch('[a-f0-9]{64}', r[key])), 'Invalid content hash')
                if 'source_asset' in r: safe_relative(r['source_asset'])
                if 'source_relative_image' in r: safe_relative(r['source_relative_image'])
                if name == 'imagenet':
                    require(r['wnid'] == classes[r['label']]['wnid'] == sid.split(':')[0], 'WNID mapping mismatch')
                if name == 'flickr':
                    require(r['candidate_index'] == r['position'] == r['label'], 'Caption candidate permutation')
                    require(type(r.get('sentid')) is int and r['karpathy_split'] in ['train','val','test'], 'Missing named-split authentication')
            n += len(rows)
    return n



PINNED_SOURCES = {'cifar100': {'repository_id': 'uoft-cs/cifar100', 'source_revision': 'aadb3af77e9048adbea6b47c21a81e47dd092ae5', 'assets': {'test-00000-of-00001.parquet': {'sha256': '98776c529bb146a9c791229df74a5cf076be9b43d82dbbd334b6a7788d73dc68', 'size_bytes': 23772751, 'repository_member': 'cifar100/test-00000-of-00001.parquet'}, 'train-00000-of-00001.parquet': {'sha256': '694865d6b990e234804f01268586c41e88bcbbb75e20858432c05ad4081aca23', 'size_bytes': 118518617, 'repository_member': 'cifar100/train-00000-of-00001.parquet'}}}, 'imagenet': {'repository_id': 'mrm8488/ImageNet1K-val', 'source_revision': 'f004a913f9170e5ff39e63f6172ee3ae918197c9', 'assets': {'data/train-00000-of-00014.parquet': {'sha256': '912d097722f4051d22e212c19c88767b1a2ad4b5cb4c3f45fa748f7208c3ceff', 'size_bytes': 530013806, 'repository_member': 'data/train-00000-of-00014.parquet'}, 'data/train-00001-of-00014.parquet': {'sha256': '010dd73afd2b2f8ba66f0ed05cca8c826ee62ec9710786580da65dd8fab0da92', 'size_bytes': 538614502, 'repository_member': 'data/train-00001-of-00014.parquet'}, 'data/train-00002-of-00014.parquet': {'sha256': 'b61aa7f3d966ae1815bba1479ceef7662f2f36921d34fdf661b4e6f7a64715da', 'size_bytes': 493309079, 'repository_member': 'data/train-00002-of-00014.parquet'}, 'data/train-00003-of-00014.parquet': {'sha256': 'ac35ea197a8c4ff8f5b5b433b753aadf65f1b597542ecf9e52fdb3fac1caee03', 'size_bytes': 479877747, 'repository_member': 'data/train-00003-of-00014.parquet'}, 'data/train-00004-of-00014.parquet': {'sha256': '84182cb027e2139094c19089ef4ec931599f05670210a7eb8ac07a01fe121b29', 'size_bytes': 494523139, 'repository_member': 'data/train-00004-of-00014.parquet'}, 'data/train-00005-of-00014.parquet': {'sha256': '8cf324cf53f4e057a69345b012b7c15e48292744dd6791978900607a49908aac', 'size_bytes': 456640745, 'repository_member': 'data/train-00005-of-00014.parquet'}, 'data/train-00006-of-00014.parquet': {'sha256': 'f2de53f764ca23f4d8907ac53d5e3a7eea51070e3900b0db5d260ff1d67c0052', 'size_bytes': 458070590, 'repository_member': 'data/train-00006-of-00014.parquet'}, 'data/train-00007-of-00014.parquet': {'sha256': 'a74f7ed520933c61add891536e1350641a69b4e7bbf136615029728e1ff1d344', 'size_bytes': 443797995, 'repository_member': 'data/train-00007-of-00014.parquet'}, 'data/train-00008-of-00014.parquet': {'sha256': '15031dd3964988efd18a25de2116b642f85ac9b411ec4b57eaff08a6858d320d', 'size_bytes': 445418642, 'repository_member': 'data/train-00008-of-00014.parquet'}, 'data/train-00009-of-00014.parquet': {'sha256': 'e383e9c5e38417877b9a5aecfbf6b243dcd75ee627378101568103710ffaf696', 'size_bytes': 454009483, 'repository_member': 'data/train-00009-of-00014.parquet'}, 'data/train-00010-of-00014.parquet': {'sha256': '1ce727439cc3710580ee39e6b277903c22720341ec669848205a094d2cf49101', 'size_bytes': 448984198, 'repository_member': 'data/train-00010-of-00014.parquet'}, 'data/train-00011-of-00014.parquet': {'sha256': 'ef8124e95f099beb616fd05076823e83173c3a100ef650655a39b1c4b8329643', 'size_bytes': 465515535, 'repository_member': 'data/train-00011-of-00014.parquet'}, 'data/train-00012-of-00014.parquet': {'sha256': '1c5847da047b50ba53ae25bd1ceb133873d3564eb566428a8db188b3f39a1de8', 'size_bytes': 472303081, 'repository_member': 'data/train-00012-of-00014.parquet'}, 'data/train-00013-of-00014.parquet': {'sha256': '23429f4c3fe44192de8ca7d44273cfd9a9514e7bc16de3961d6052e79cc080b6', 'size_bytes': 511384625, 'repository_member': 'data/train-00013-of-00014.parquet'}}}}


def validate_manifest(doc):
    """Validate sanitized structure and independently pinned recovered sources."""
    def sanitize(value):
        if isinstance(value, dict):
            forbidden = {'caption', 'captions', 'raw_caption', 'raw_text', 'input_ids',
                         'pixel_values', 'access_token', 'reference_buffers', 'token_ids',
                         'password', 'api_key', 'input_path', 'private_path', 'path'}
            require(not (set(value) & forbidden), 'Restricted field in portable manifest')
            for child in value.values(): sanitize(child)
        elif isinstance(value, list):
            for child in value: sanitize(child)
        elif isinstance(value, str):
            require(not value.startswith(('/', '~/', 'file:')), 'Absolute or home locator forbidden')
            require(not re.search(r'(?i)((?<![a-z])[a-z]:[/\\]|\\\\)', value),
                    'Machine locator forbidden')
    sanitize(doc)
    count = _validate_structure(doc)
    for name, pinned in PINNED_SOURCES.items():
        data = doc['datasets'][name]
        for key in ['repository_id', 'source_revision']:
            require(data.get(key) == pinned[key], 'Missing or changed pinned '+key)
        assets = data.get('source_assets', [])
        require(len(assets) == len(pinned['assets']), 'Missing or duplicate source member')
        observed = set()
        for asset in assets:
            member = asset['asset']; require(member not in observed, 'Duplicate member')
            observed.add(member); expected = pinned['assets'].get(member)
            require(expected is not None, 'Unknown source member')
            for key in ['sha256', 'size_bytes', 'repository_member']:
                require(asset.get(key) == expected[key], 'Changed source member '+key)
            safe_relative(asset['repository_member'])
            expected_url = 'https://huggingface.co/datasets/'+data['repository_id']+'/resolve/'+data['source_revision']+'/'+asset['repository_member']
            require(asset.get('retrieval_url') == expected_url, 'Pinned member URL mismatch')
        evidence = data.get('acquisition_evidence', {})
        require(evidence.get('level') == 'LOCAL_CACHE_CHAIN_AUTHENTICATED', 'Missing source evidence scope')
        for key in ['current_external_availability_verified', 'official_rights_authenticated',
                    'publisher_signature_verified', 'official_original_content_crosscheck']:
            require(evidence.get(key) is False, 'Unsupported access or rights assertion')
    food = doc['datasets']['food101']['acquisition_evidence']
    require(food.get('level') == 'RECORDED_SOURCE_LOCK_ONLY_NOT_NEWLY_AUTHENTICATED', 'Food101 source scope changed')
    require(food.get('repository_cache_chain_authenticated') is False, 'Unsupported Food101 authentication')
    for key in ['current_external_availability_verified', 'official_rights_authenticated']:
        require(food.get(key) is False, 'Unsupported Food101 access or rights assertion')
    return count


def check_assets(root, assets):
    for a in assets:
        p = inside(root, a['asset'])
        require(file_sha(p) == a['sha256'], 'Source asset hash mismatch: '+a['asset'])
        if 'size_bytes' in a: require(p.stat().st_size == a['size_bytes'], 'Source size mismatch')


def pixel_sha(image):
    image = image.convert('RGB')
    return sha(('RGB:%d:%d:' % image.size).encode('ascii') + image.tobytes())


def check_image(raw, row, mode):
    from PIL import Image
    expected = row.get('source_encoded_sha256') if mode == 'source' else row['image_sha256']
    require(expected is not None and sha(raw) == expected, 'Encoded image mismatch')
    with Image.open(io.BytesIO(raw)) as image:
        require(pixel_sha(image) == row['pixel_sha256'], 'Decoded RGB mismatch')


def check_source_label(row, record, dataset):
    key = 'fine_label' if dataset == 'cifar100' else 'label'
    require(key in record and type(record[key]) is int and record[key] == row['label'], 'Source label mismatch')


def check_caption_rows(rows, doc):
    images = doc['images']; lookup = {r['filename']:r for r in images}
    require(len(lookup) == len(images), 'Duplicate annotation filename')
    for r in rows:
        require(r['candidate_index'] == r['position'] == r['label'], 'Candidate order mismatch')
        source = lookup[r['stable_id']]
        require(source['split'] == r['karpathy_split'], 'Named split mismatch')
        first = source['sentences'][0]
        require(first['sentid'] == r['sentid'], 'First caption sentid mismatch')
        require(sha(first['raw'].encode('utf-8')) == r['caption_utf8_sha256'], 'Exact raw caption mismatch')
    return len(rows)


def check_cifar_binary_records(raw, rows):
    """Alternative RGB/fine-label identity only; not parquet byte/order recovery."""
    require(len(raw) % 3074 == 0, 'Malformed CIFAR100 binary length')
    wanted = {(r['pixel_sha256'], r['label']) for r in rows}; found = set()
    for i in range(0, len(raw), 3074):
        body = raw[i+2:i+3074]
        rgb = bytes(v for j in range(1024) for v in (body[j], body[1024+j], body[2048+j]))
        key = (sha(b'RGB:32:32:'+rgb), raw[i+1])
        if key in wanted: found.add(key)
    require(found == wanted, 'Missing selected RGB/fine-label identity in alternative binary input')
    return len(rows)


def validate_dataset(manifest, name, root, annotation_zip=None):
    validate_manifest(manifest)
    data = manifest['datasets'][name]
    rows = [r for rs in data['splits'].values() for r in rs]
    if name == 'dtd':
        check_assets(Path(root)/'labels', data['source_assets'])
        split_sets = {s:set((Path(root)/'labels'/(s+'1.txt')).read_text(encoding='utf-8').splitlines())
                      for s in ['train','val','test']}
        for r in rows:
            relative = r['source_relative_image']
            require(relative in split_sets[r['official_split']], 'Original DTD split membership mismatch')
            require(relative.split('/')[0] == data['classes'][r['label']]['name'], 'DTD label mismatch')
            check_image(inside(Path(root)/'images', relative).read_bytes(), r, 'source')
    elif name in ['cifar100','food101','imagenet']:
        import pyarrow.parquet as pq
        check_assets(root, data['source_assets'])
        if name == 'imagenet': check_assets(root, data['metadata_assets'])
        grouped = defaultdict(dict)
        for r in rows:
            require(r['source_row'] not in grouped[r['source_asset']], 'Repeated source row')
            grouped[r['source_asset']][r['source_row']] = r
        for asset, selected in grouped.items():
            offset = 0; checked = set()
            for batch in pq.ParquetFile(inside(root, asset)).iter_batches(batch_size=256):
                stop = offset + batch.num_rows
                positions = [i for i in selected if offset <= i < stop]
                if positions:
                    records = batch.to_pylist()
                    for i in positions:
                        r = selected[i]; rec = records[i-offset]
                        check_source_label(r, rec, name)
                        col = r.get('source_image_column','image'); value = rec[col]
                        raw = value['bytes'] if isinstance(value,dict) else value
                        require(isinstance(raw,bytes), 'Missing encoded source bytes; external paths not followed')
                        check_image(raw, r, 'source'); checked.add(i)
                offset = stop
            require(checked == set(selected), 'Missing parquet selected rows')
    elif name == 'flickr':
        require(annotation_zip is not None, 'Author annotation ZIP must be supplied separately')
        ann = data['annotation_source']
        require(file_sha(annotation_zip) == ann['zip_sha256'], 'Author ZIP hash mismatch')
        with zipfile.ZipFile(annotation_zip) as z:
            require(z.namelist().count(ann['member']) == 1, 'Missing/ambiguous annotation member')
            raw = z.read(ann['member'])
        require(sha(raw) == ann['member_sha256'], 'Annotation member hash mismatch')
        check_caption_rows(rows, json.loads(raw))
        for r in rows:
            check_image(inside(root,r['stable_id']).read_bytes(),r,'materialized')
    else: raise ValueError('Unsupported acquisition dataset')
    return dict(status='PASS_ACQUIRED_INPUT_IDENTITY', dataset=name, rows=len(rows),
                legal_permission_determined=False, new_science=False, gpu_used=False)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',type=Path,default=Path(__file__).with_name('InputAcquisitionManifest_v3.json'))
    p.add_argument('--manifest-sha256',required=True,help='Trusted separately supplied manifest fingerprint')
    p.add_argument('--dataset',choices=['dtd','cifar100','food101','imagenet','flickr'])
    p.add_argument('--asset-root',type=Path)
    p.add_argument('--annotation-zip',type=Path)
    a = p.parse_args()
    try:
        require(file_sha(a.manifest) == a.manifest_sha256, 'Manifest fingerprint mismatch')
        doc = json.loads(a.manifest.read_bytes()); n=validate_manifest(doc)
        if a.dataset:
            require(a.asset_root is not None, 'Acquisition root required')
            result = validate_dataset(doc,a.dataset,a.asset_root,a.annotation_zip)
        else: result=dict(status='PASS_SANITIZED_MANIFEST_ONLY',selected_rows=n,acquisition_validated=False)
        print(json.dumps(result,sort_keys=True))
    except Exception as e:
        print(json.dumps(dict(status='BLOCKED',error_type=type(e).__name__,message=str(e))),file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__': main()
