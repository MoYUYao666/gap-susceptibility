# R1-8 / R2 availability: configuration and checkpoint supply

## Explicit answer to the YAML request

The **with-configurations successor** supplies 66 named JSON/YAML pairs:

* `config/scientific_core/`: 18 core trajectories (DTD/CIFAR100/Food101,
  text-only/both-tower LoRA, seeds42/43/44).
* `config/scientific_extension/`: 24 spectral trajectories (DTD/CIFAR100,
  early/late × frozen-reference/dynamic, seeds42/43/44).
* `config/methods_fixed24/`: 24 actual method-run configurations (DTD/CIFAR100,
  router-static/router-input/rope-fixed/rope-learned, seeds42/43/44).

These are **all recorded fields**, not fresh defaults or a reconstructed claim
that every historically effective setting was recorded. The first42 reuse the
existing recorded exports. Original YAML/JSON semantic equality, actual per-run
Identity equality, actual Inputs SHA256 and recorded protocol/configuration fields
are checked before sanitization. In particular, the 24 spectral Inputs records
have **no `effective_configuration` field**. Their exact recorded protocols,
identity, trainable/optimizer manifests, environment and bound runtime sources
are supplied; `not_recorded_fields` explicitly retains that omission. It would
be false to invent a complete per-run effective-configuration object from defaults.
No historical state is restored by exporting a configuration.

Each method config comes directly from its actual `Identity.json/config`, with
original canonical config SHA, source-completion and independent saved-state
acceptance bindings. The portable version replaces private input/model paths
with logical excluded references and has a **separate sanitized config SHA**;
it does not falsely validate the original path-bearing config SHA against altered
bytes. Recorded alpha/router fields have arm-specific applicability; shared
settings do not imply those parameters are active in every arm. Archival runtime/
runner sources are included for that mapping, but are never imported by scalar replay.

The new `.yaml` files use **JSON-compatible YAML1.2**, preserving all recorded
values/types while avoiding a reader-side YAML dependency. The paired `.json`
files are semantically identical. These are sanitized successors, not byte-identical
original YAML files. Original export/source fingerprints remain in SourceBindings.
`config/ConfigIndex.json` lists every run and its exact applicability/omissions.

## Checkpoint manifest is not checkpoint distribution

`checkpoints/CheckpointManifest.json` supplies **metadata only**:

* 252 local core/spectral state records: 42 trajectories × six separate native/
  initial/adapted states. Native and epoch0 can share content but are not conflated.
* 120 distinct method epoch checkpoints: 24 trajectories × epoch0–4, plus 24
  latest restart aliases. Aliases, native references and epochs are not extra runs.
* Every entry has logical local locator, hash/size and provenance. Core/spectral
  binary hashes inherit the bound prior inventory; method binary hashes inherit
  bound Completion and existing independent fixed24 saved-state acceptance. This
  task checks metadata and sizes without reopening/checking tensor bytes.

No state, optimizer, feature/score or foundation binary is copied into this ZIP.
The manifest explicitly marks `payload_included:false` and `public_snapshot:false`.
Local availability, private metadata supply, lawful third-party acquisition and
public access are separate facts. This does not put replacement states into the
old public DOI, cure missing historical states, establish redistribution rights,
or upgrade the separate ongoing forward/resume matrix to scientific acceptance.

## Preconfiguration archive preservation

The earlier current-statistics ZIP and its receipt remain unchanged. Its 50-member
inventory did **not** contain these configuration/checkpoint directories, and its
SHA must not be cited as if it did. Only the explicitly named **with_configs**
successor may be cited for the 42+24 YAML/configuration and checkpoint-manifest
scope. The delivery receipt binds both identities and records supersession narrowly.
