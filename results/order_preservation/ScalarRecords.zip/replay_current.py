"""Portable scalar arithmetic replay. No tensor, image, model or workspace fallback."""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '2'
import argparse
from collections import defaultdict
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise ValueError(message)


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


safe = module(HERE / 'safe_archive.py', 'safe_archive_current')


def read(path):
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'Duplicate JSON key')
            result[k] = v
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def same(actual, expected, pointer='', tolerance=0):
    """Compare recomputed values, never a digest substitute for computation."""
    if type(actual) in (int, float) and type(expected) in (int, float):
        require(math.isfinite(actual) and math.isfinite(expected), 'Nonfinite result ' + pointer)
        require(actual == expected or tolerance and math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance), 'Scalar mismatch ' + pointer + ': ' + repr((actual, expected)))
    elif isinstance(actual, dict) and isinstance(expected, dict):
        actual = {str(k): v for k, v in actual.items()}
        expected = {str(k): v for k, v in expected.items()}
        require(set(actual) == set(expected), 'Object schema mismatch ' + pointer)
        for k in actual:
            same(actual[k], expected[k], pointer + '/' + k, tolerance)
    elif isinstance(actual, list) and isinstance(expected, list):
        require(len(actual) == len(expected), 'List length mismatch ' + pointer)
        for i, (a, b) in enumerate(zip(actual, expected)):
            same(a, b, pointer + '/' + str(i), tolerance)
    else:
        require(type(actual) is type(expected) and actual == expected, 'Value mismatch ' + pointer)


def pointer(value, path):
    for token in path.strip('/').split('/'):
        token = token.replace('~1', '/').replace('~0', '~')
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def csvrows(path):
    with Path(path).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def csvwrite(path, rows):
    require(rows, 'Empty CSV result')
    with Path(path).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def without_pointers(value):
    if isinstance(value, dict):
        return {k: without_pointers(v) for k, v in value.items() if not k.endswith('_pointer') and not k.endswith('_pointers')}
    if isinstance(value, list):
        return [without_pointers(v) for v in value]
    return value


def core_replay(out, baseline):
    r = module(baseline / 'replay.py', 'baseline_scalar_api')
    ns, _, _, _, _, _ = r.scientific_apis()
    inputs = read(HERE / 'inputs/core/Views.json')
    targets = read(HERE / 'expected/core/Trajectories.json')
    index = {x['cell']['id']: x for x in inputs}
    require(len(index) == len(inputs) == 18, 'Complete core 18 identities')
    protocol = read(baseline / 'source/Protocol.json')
    require({x['cell']['id'] for x in inputs} == {x['id'] for x in protocol['cells']}, 'Core locked identities')
    ns['_receipt'] = lambda directory: ({}, 'scalar-only-no-state-receipt')
    ns['_spec'] = lambda lock, dataset, view: ([], [])
    def loader(directory, view, rows, texts, receipt):
        measured = index[directory.parent.name]['states'][directory.name][view]
        return dict(scores=r.np.zeros((1, 2)), measure=measured), {}
    ns['load_view'] = loader
    ns['_measure'] = lambda reference, arrays, rows, view, protocol: arrays['measure']
    derived = []
    for source, expected in zip(inputs, targets):
        require(set(source['states']) == set(r.STATES), 'Six core states')
        require(all(set(v) == set(r.VIEWS) for v in source['states'].values()), 'Locked core four views')
        result, _ = ns['analyze_unit'](out / 'scalar_identity' / source['cell']['id'], source['cell'], {}, protocol)
        projected = {k: result[k] for k in ('cell', 'choices', 'outcomes', 'correlations', 'scalar_estimands')}
        same(projected, expected)
        derived.append(projected)
    summary = ns['_panel'](derived, protocol)
    same(summary, read(HERE / 'expected/core/Summary.json'))
    cell = module(HERE / 'code/core_cells.py', 'current_core_cells')
    cell.core = SimpleNamespace(digest=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest())
    # Only pointer metadata needs a local placeholder; no state/score assets are opened.
    scalar_bundle = out / 'core_scalar_bundle'
    write(scalar_bundle / 'Trajectories.json', dict(trajectories=derived))
    cells = without_pointers(cell.cell_panel(derived, summary, scalar_bundle, out))
    same(cells, read(HERE / 'expected/core/Cells.json'))
    write(out / 'CoreTrajectories.json', derived)
    write(out / 'CoreSummary.json', summary)
    write(out / 'CoreCells.json', cells)
    flat = []
    for table in cells['tables']:
        for x in table['cells']:
            flat.append(dict(scalar=table['scalar'], dataset=x['dataset'], mode=x['mode'], estimate=x['estimate'], interval_low=x['interval95'][0] if x['interval95'] else None, interval_high=x['interval95'][1] if x['interval95'] else None, n_planned=3, reason=x['reason']))
    csvwrite(out / 'CoreNamedCells.csv', flat)
    return dict(trajectories=18, seed_ids=[42, 43, 44], sources=['dtd', 'cifar100', 'food101'], scalar_estimands=sum(len(x['scalar_estimands']) for x in derived), source_mode_cells=6, named_tables=5, bootstrap_replicates=20000, bootstrap_seed=20261121, exact=True, scalar_operators='Original baseline collector/statistics and original cell_report functions; not independent feature measurement')


def posthoc_replay(out):
    p = module(HERE / 'code/posthoc.py', 'current_posthoc')
    b = module(HERE / 'code/bridge.py', 'current_bridge')
    rows = read(HERE / 'inputs/posthoc/AnalysisRows.json')['rows']
    bridge_rows = read(HERE / 'inputs/posthoc/BridgeRows.json')['rows']
    p.validate_flickr(read(HERE / 'inputs/acquisition/FlickrAuthentication.json'))
    result = p.reduce_rows(rows)
    same(result, read(HERE / 'expected/posthoc/FullSummary.json'))
    p.check_comparisons(result, read(HERE / 'expected/posthoc/AnalyzerComparisons.json'))
    bridge = p.reduce_bridge(bridge_rows)
    same(bridge, read(HERE / 'expected/posthoc/BridgeSummary.json'))
    original = b.paired_summary(bridge_rows)
    same(original, read(HERE / 'expected/posthoc/BridgeProducerSummary.json'))
    for joined in bridge_rows:
        selected = [r for r in rows if all(r[k] == joined[k] for k in ('dataset', 'arm', 'seed', 'view', 'epoch', 'mode'))]
        require(len(selected) == 1 and selected[0]['metrics'][joined['metric']] == joined['method_value'], 'Bridge method explicit scalar join')
    sources = {'FullSummary.json': result, 'BridgeSummary.json': {'rows': bridge}}
    companion = read(HERE / 'reference/posthoc/PosthocNumericCompanion.json')
    bindings = read(HERE / 'reference/posthoc/CompanionBindings.json')
    require(len(bindings) == len(companion['rows']) == 156, 'All current numeric companion rows required')
    for i, binding in enumerate(bindings):
        require(binding['companion_pointer'] == '/rows/' + str(i), 'Companion binding order')
        expected = pointer(sources[binding['source']], binding['source_pointer'])
        same(companion['rows'][i]['statistics'], expected)
    flat = []
    for x in companion['rows']:
        stat = x['statistics']
        flat.append({k: x.get(k) for k in ('dataset', 'arm', 'view', 'split', 'epoch', 'mode', 'metric', 'comparison', 'left', 'right')} | dict(mean=stat['mean'], sample_sd=stat['sample_sd_ddof1'], n_planned=3, seed42=stat['seed_values']['42'], seed43=stat['seed_values']['43'], seed44=stat['seed_values']['44'], positive=stat.get('positive_seeds'), negative=stat.get('negative_seeds'), zero=stat.get('zero_seeds'), units='fraction_or_named_CG'))
    write(out / 'PosthocFullSummary.json', result)
    write(out / 'BridgeSummary.json', bridge)
    csvwrite(out / 'PosthocCurrent156.csv', flat)
    for comparison, filename in [('bridge_difference', 'Bridge8x3.csv'), ('route_replacement_minus_default', 'Uniform4x3.csv'), ('default_epoch4_minus_shared_native', 'Native8x3.csv')]:
        selected = [r for r in flat if r['comparison'] == comparison and r['view'] in ('imagenet', 'flickr') and (filename != 'Uniform4x3.csv' or r['left'].endswith('/uniform'))]
        if selected:
            csvwrite(out / filename, selected)
    return dict(units=24, adapted_states_per_unit=5, separate_native=True, scalar_rows=len(rows), bridge_metric_seed_rows=len(bridge_rows), companion_rows=156, aggregates=len(result['aggregates']), fixed_epoch4_deltas=len(result['fixed_epoch4_deltas']), state_deltas=len(result['state_deltas']), sample_sd='ddof=1 across three paired seed differences; not CI', seed_ids=[42, 43, 44], bridge_geometry_compared=False, exact=True)


def mechanism_replay(out):
    report = {}
    for family, name, seeds in [('layers', 'Layers.csv', [42, 43, 44]), ('contexts', 'Contexts.csv', [42, 137, 2026])]:
        rows = csvrows(HERE / 'inputs/mechanism' / name)
        require(len(rows) == (1200 if family == 'layers' else 72), 'Mechanism full inventory')
        identity = ['source', 'seed', 'mode', 'view', 'template'] if family == 'layers' else ['source', 'seed', 'mode', 'view']
        baselines = {}
        for r in rows:
            default = r['operation'] == 'default' if family == 'layers' else r['text'] == 'trained' and r['vision'] in ('trained', 'absent')
            key = tuple(r[k] for k in identity)
            if default:
                require(key not in baselines, 'Duplicate mechanism baseline')
                baselines[key] = r
        groups = defaultdict(dict)
        for r in rows:
            base = baselines[tuple(r[k] for k in identity)]
            accuracy = 100 * (float(r['accuracy']) - float(base['accuracy']))
            tau = float(r['tau_b']) - float(base['tau_b'])
            same(accuracy, float(r['delta_accuracy_pp']), tolerance=2e-12)
            same(tau, float(r['delta_tau_b']))
            columns = [k for k in r if k not in ('seed', 'evidence_index', 'accuracy', 'delta_accuracy_pp', 'tau_b', 'delta_tau_b', 'centroid_gap', 'winner_margin', 'top1_agreement')]
            key = tuple((k, r[k]) for k in columns)
            require(int(r['seed']) not in groups[key], 'Duplicate mechanism seed')
            groups[key][int(r['seed'])] = dict(delta_accuracy_pp=accuracy, delta_tau_b=tau, accuracy=float(r['accuracy']), tau_b=float(r['tau_b']), centroid_gap=float(r['centroid_gap']), winner_margin=float(r['winner_margin']), top1_agreement=float(r['top1_agreement']))
        aggregates = []
        for key, values in sorted(groups.items()):
            require(sorted(values) == seeds, 'Complete mechanism three-seed panel')
            for metric in next(iter(values.values())):
                xs = [values[s][metric] for s in seeds]
                aggregates.append(dict(key) | dict(metric=metric, mean=statistics.fmean(xs), sample_sd=statistics.stdev(xs), seed_ids=','.join(map(str, seeds)), n=3, positive=sum(x > 0 for x in xs) if metric.startswith('delta_') else None, negative=sum(x < 0 for x in xs) if metric.startswith('delta_') else None, zero=sum(x == 0 for x in xs) if metric.startswith('delta_') else None))
        csvwrite(out / (family.capitalize() + 'SeedSummary.csv'), aggregates)
        report[family] = dict(rows=len(rows), fixed_operation_groups=len(groups), seed_ids=seeds, templates_pooled=False, views_pooled=False, not_capacity_isolated=True)
    return report


def source_methods_replay(out):
    root = HERE / 'inputs/source_methods'
    rows = csvrows(root / 'Readouts.csv')
    keys = ('dataset', 'arm', 'seed', 'split', 'epoch')
    index = {tuple(r[k] for k in keys): r for r in rows}
    require(len(index) == len(rows), 'Duplicate source readout')
    expected = read(HERE / 'reference/source_methods/Summary.json')
    def item(d, a, s, sp, e):
        return index[(d, a, str(s), sp, str(e))]
    summaries = []
    for g in expected['comparisons']:
        values = []
        for x in g['values']:
            a = item(g['dataset'], g['left'], x['seed'], g['split'], g['epoch'])
            b = item(g['dataset'], g['right'], x['seed'], g['split'], g['epoch'])
            scale = 100 if g['unit'] == 'percentage_points' else 1
            difference = scale * (float(a[g['metric']]) - float(b[g['metric']]))
            same(difference, x['difference'], tolerance=2e-12)
            values.append(difference)
        require(len(values) == 3 and sorted(x['seed'] for x in g['values']) == [42,43,44], 'Three source paired seeds')
        for key, value in dict(mean=statistics.fmean(values), minimum=min(values), maximum=max(values), positive_seeds=sum(x>0 for x in values), negative_seeds=sum(x<0 for x in values), zero_seeds=sum(x==0 for x in values)).items():
            same(value, g[key], tolerance=2e-12)
        summaries.append({k:g[k] for k in ('dataset','split','epoch','left','right','metric','unit')} | dict(mean=statistics.fmean(values), sample_sd=statistics.stdev(values), n=3))
    for r in csvrows(root / 'TrajectoryDifferences.csv'):
        same(100 * (float(r['method_accuracy']) - float(r['baseline_accuracy'])), float(r['difference_pp']), tolerance=2e-12)
        # These row references are zero-based data-row indices in the delivered Readouts CSV.
        a, b = rows[int(r['method_csv_row'])], rows[int(r['baseline_csv_row'])]
        require(all(a[k] == r[k] for k in ('dataset','arm','seed','split','epoch')), 'Source trajectory method join')
        same(float(a['classification_accuracy']), float(r['method_accuracy']))
        same(float(b['classification_accuracy']), float(r['baseline_accuracy']))
    for r in csvrows(root / 'InitializationChanges.csv'):
        args = r['dataset'], r['arm'], r['seed'], r['split']
        a, b = item(*args, -1), item(*args, 0)
        final = item(*args, max(expected['method_epochs']))
        values = [float(x['classification_accuracy']) for x in (a,b,final)]
        for name, value in [('epoch0_minus_native_pp', 100*(values[1]-values[0])), ('final_minus_epoch0_pp',100*(values[2]-values[1])), ('final_minus_native_pp',100*(values[2]-values[0]))]:
            same(value, float(r[name]), tolerance=2e-12)
    csvwrite(out / 'SourceMethodComparisons.csv', summaries)
    return dict(readout_rows=len(rows), paired_comparisons=len(summaries), seed_ids=[42,43,44], source_only=True, transfer_claim=False, numeric_abs_tolerance=2e-12)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    require(not out.exists() and not out.is_relative_to(HERE), 'Output must be a new directory outside package')
    members = safe.verify_tree(HERE)
    out.mkdir(parents=True)
    baseline = out / 'baseline'
    safe.extract(HERE / 'dependencies/EditorialCodeScalar_v4.zip', baseline, read(HERE / 'dependencies/EditorialMemberSHA.json'))
    safe.extract(HERE / 'dependencies/PortableAcquisition_v3.zip', out / 'acquisition', read(HERE / 'dependencies/AcquisitionMemberSHA.json'))
    import numpy as np
    import scipy
    report = dict(status='RUNNING_CURRENT_SCALAR_REPLAY', package_members_verified=members,
                  interpreter=sys.executable, python=sys.version, numpy=np.__version__, scipy=scipy.__version__,
                  cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'], cpu_thread_limit=2)
    for name, function in [('core', lambda:core_replay(out, baseline)), ('posthoc', lambda:posthoc_replay(out)), ('mechanism', lambda:mechanism_replay(out)), ('source_methods', lambda:source_methods_replay(out))]:
        report[name] = function()
        print(name + ': PASS', flush=True)
    g = module(HERE / 'code/gradient.py', 'current_gradient')
    gradient = g.reduce_cells(read(HERE / 'inputs/gradient/Cells.json'))
    same(gradient, read(HERE / 'expected/gradient/Summary.json'))
    write(out / 'GradientSummary.json', gradient)
    report['gradient'] = dict(rows=48, training_units=6, seed_ids=[42,43,44], nested_batches_per_epoch=4, batch_rows=32, autograd_recomputed=False, scores_remeasured=False, exact=True)
    s = module(HERE / 'code/sampling.py', 'current_sampling')
    q = read(HERE / 'inputs/sampling/QuerySummary.json')
    c = read(HERE / 'inputs/sampling/CostResults.json')
    products = {'QueryReadouts.csv':s.query_rows(q), 'QueryWorstErrors.csv':s.worst_rows(q['conditions'],q['design']['budgets'],s.METRICS), 'CostReadouts.csv':s.cost_rows(c)}
    for filename, values in products.items():
        s.csv_check(HERE / 'expected/sampling' / filename, values)
        csvwrite(out / filename, values)
    report['sampling_cost'] = dict(query_stat_rows=len(products['QueryReadouts.csv']), draw_values=39*6*50*8, cost_passes=36, warmups_per_budget=2, timed_rounds_per_budget=7, methods_per_pass=3, new_timing=False, original_row_tau_recomputed=False, exact=True)
    if (HERE / 'config/ConfigIndex.json').is_file():
        config_module = module(HERE / 'config_validate.py', 'current_config_validate')
        report['configuration_checkpoint_metadata'] = config_module.validate(HERE)
        write(out / 'ConfigurationCheckpointVerification.json', report['configuration_checkpoint_metadata'])
    # The baseline remains byte-identical; it is not executed as a producer.
    report.update(status='PASS_CURRENT_STATISTICAL_TIER_SCALAR_REPLAY', models_loaded=False, gpu_used=False, training=False, arrays_loaded=False, public_release=False, full_public_reproducibility=False, original_strict_failure_unchanged=True)
    write(out / 'Replay.json', report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
