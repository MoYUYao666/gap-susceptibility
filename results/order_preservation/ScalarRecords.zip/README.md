# A1 current statistical-tier attachment v1

## With-configurations successor

The explicitly named `with_configs` successor also supplies **42 core/spectral
recorded configuration YAML/JSON pairs plus 24 actual method-run pairs**, together
with the **local-only** checkpoint hash/size manifest (252 core/spectral states,
120 method epoch checkpoints and 24 latest aliases). See `ConfigurationScope.md`
and `config/ConfigIndex.json`. Existing42 exports are verified against actual
records, not defaults. Spectral `effective_configuration` was not recorded for
24 runs; that omission remains explicit, with exact recorded protocol/identity/
runtime recipes supplied instead. No checkpoint binary or public snapshot is
supplied. The preconfiguration archive and its original receipt are preserved
and do not gain these members retroactively.

**Local additive attachment, not a public release and not full public reproducibility.**
This attachment adds current v30 descriptive scalar replay to the unchanged editorial
v4 baseline. No manuscript, image, caption, token buffer, feature/score tensor,
checkpoint, foundation weight or credential is supplied as a current-tier payload.
No source-data download, model execution, training or timing measurement is performed.

## One portable entrypoint

Use a Python environment with NumPy and SciPy (versions actually tested are in the
separate delivery receipt). No new installation is required on the author's machine.
Run from the extracted attachment, with a **new output directory outside it**:

```powershell
$env:CUDA_VISIBLE_DEVICES=''
$env:OMP_NUM_THREADS='2'
$env:MKL_NUM_THREADS='2'
python -B -I replay_current.py --output '<new-isolated-output-directory>'
python -B -I -m unittest discover -s . -p test_current.py -v
```

The entrypoint verifies member SHA256, safely extracts the two unchanged dependency
archives into its output, then computes—not merely hashes—the current scalar tables:

| Family | Explicit operands | Recomputed outputs / checks |
|---|---|---|
| Core | 18 trajectories, six saved scalar states, four views; three seeds per source/mode | Selectors, regrets, four-epoch correlations, 6,156 scalar estimands; source-local cells, five named tables, equal-fixed-source paired bootstrap/deletion summaries |
| Posthoc | All 672 scalar rows: 24 units, epochs 0–4, separate native and router uniform/calibration-mean | 9,016 aggregates, 2,460 fixed-epoch4 contrasts, 1,968 state contrasts; no all-row tau remeasurement |
| Ordinary-LoRA bridge | All 72 matched endpoint/seed rows with explicit method and baseline scalars | 24 paired endpoint summaries, SD and signs; joins method scalars against recovery02 rows |
| Current numeric companion | All 156 rows and exact logical field bindings | Compare every current published seed value, mean, sample SD and direction count against recomputed products |
| Mechanism | 1,200 layer rows; 72 context rows | Default-relative accuracy/tau deltas, fixed-operation seed mean/sample SD; no template/view pooling |
| Sampling/cost | 93,600 recorded query-draw estimates and 36 timing passes | 1,872 query-statistic rows, 48 worst-tail rows, 12 cost rows; paired-sum medians, not new timings |
| Gradient | 48 finite batch records within six source–seed units | Exact rational preservation reduction, DecimalCE averages/deltas, stored gradient cosine arithmetic; not autograd certification |
| Source methods | Current readouts and all signed comparison records | Source-only paired means/SD, initialization changes and ordinary-LoRA source trajectory deltas |

Machine-readable unfavorable, mixed, undefined and zero cells are retained. Fraction,
percentage-point, cosine and correlation units are not interchanged. See `Scope.md`.
The old v4 archive is nested **byte-identically**, not regenerated or relabelled as a
current full-science pass. Its historical original-array strict failure remains true.

## Integrity and provenance

`MemberSHA256.json` authenticates every other payload member. The externally supplied
archive receipt additionally hashes the manifest itself and every ZIP member. The
two dependency member inventories permit bounded, traversal-safe, CRC/SHA extraction.
`SourceBindings.json` records original input hashes, projection identities and exact
source-code extraction ranges without private absolute paths. Private source paths
remain in the separate local `InternalBindings.json`, **outside this ZIP**.
The current sanitized projections are not replacements for the excluded raw evidence.

`code/posthoc.py`, `code/bridge.py`, `code/gradient.py` and `code/core_cells.py`
retain exact selected original function bodies with explicit portable imports. The
full independent reducer is included with only its local default Analysis path
redacted; it is archival source, not the portable entrypoint. The baseline supplies
the unchanged original statistical operators. This is scalar replay, not an
independent statistical implementation of every original scientific measurement.

## Acquisition and still-missing tiers

`Acquisition.md` describes exact portable_v3 inputs, commands, revision/mapping rules,
and the authenticated Flickr annotation snapshot with mixed 473/20/19 split.
`ExcludedTierIndices.json` identifies the separate **local-only** state/feature/score
indices. They are locators and hashes, not publicly distributed assets. Acquisition
structure validation is not acquired-input, image-content, legal-rights or training
reproduction validation. No acceptance of data terms or redistribution is implied.

Previous packages, global navigation, candidate sources and scientific assets are
unchanged. Author review, rights clearance and any later publication remain separate.
