# Statistical scope and unfulfilled tiers

## Current finite descriptive layer

Core ordinary-LoRA has three fixed sources (DTD, CIFAR100, Food101), two placement
modes and seeds 42/43/44: 18 trajectories, nine source–seed pairs, six saved states
per trajectory. Four trained candidate epochs 1–4 determine selectors using source
calibration only; source test and transfer outcomes do not choose checkpoints.
The existing 20,000 paired-seed resamples (seed 20261121), equal fixed-source weights
and source-local cells are replayed from scalar operands. They are not population
inference over a distribution of unseen datasets, images or checkpoints.

Posthoc contains DTD/CIFAR100 × four arms × seeds 42/43/44 = 24 units. Epochs 0–4
and separate native anchors are repeated measurements. Uniform and calibration-mean
router interventions use epoch4; uniform is a **no-retraining same-checkpoint
unit-strength intervention**, with fixed adapters in both towers, not a separately
retrained competitor. Default-operation epoch4 cells are compared with shared native
anchors; this does not assert that all learned states improve. RoPE arms are
negative-result comparators, not negative controls. All signs are retained.

The bridge is 24 cells × three seed differences = 72 endpoint/seed rows, not 72 new
trainings. Its source, seed, cohort and shared optimizer recipe are matched; capacity,
parameterization, initialization draws and per-parameter learning rates are not
isolated. No capacity-isolated superiority, causal diagnosis, bridge geometry
comparison or retrieved-pair repair is established. Twelve or 24 endpoint cells
are dependent summaries, not additional replicates. Sample SD is ddof=1 over three
paired seed differences, **not a confidence interval**. Performance is fraction in
posthoc numeric files; multiply by 100 only for percentage-point presentation.

CG paths remain separate: campaign canonical `CANONICAL_CG_BINARY64_FSUM_V1` uses
binary64 normalization plus fsum; posthoc `CG_l2_means_float64` uses double means of
saved individually normalized features **without FP64 renormalization**. Neither
is remeasured here. They are never pooled, substituted or asserted bitwise equal.
Undefined tau remains null and invalidates the three-seed aggregate; no imputation.

Layer probes use seeds 42/43/44 at epoch4, four dependent templates and two source
views. Context probes use seeds **42/137/2026** at epoch8, text/dual-context modes
and trained/initial context operations. These are separate designs, not pooled
with the layer seeds or transfer studies. Their calibration/test scalars are
source-domain measurements, not as-use transfer evidence. Gradient records use
seeds 42/43/44, epochs1/4 and four nested 32-row batches: 48 batches inside six
training units; 144 parameter tensors, 72 shared-A pairs and 720 B-head slices
are not extra training replicates. Saved gradient direction is inherited; no
independent autograd, full-model kernel or GPU error bound is newly verified.

Sampling draws are 50 repetitions at each of six budgets for 39 fixed conditions
and eight metrics, seed20261124. Their error ranges/p95 are empirical finite-panel
sampling descriptions, not population CIs or independent training seeds. Timing
uses four budgets, two excluded warmups and seven recorded timed rounds, each with
three readout methods and the same shared pass. Constructed total is the median
of paired shared-plus-readout sums, not sum of medians, independent workflows or
a new hardware throughput measurement.

## Missing / separate local tiers

1. **Acquired-input tier:** portable_v3 specifies exact acquisition and matching,
   but no images/captions or downloads are included. Structure-only validation in
   this new attachment is not a fresh bulk input authentication. Original local
   input checks have their own immutable receipts. Flickr annotation ZIP/member
   is locally authenticated, not dataset-creator split or upstream image rights.
2. **Feature/score metric tier:** original arrays, score matrices, token/reference
   buffers and features are excluded, not copied or cleared for redistribution.
   Thus full-row tau, RGB preprocessing, CG measurement and DecimalCE from scores
   cannot be regenerated from this attachment. See the saved-array validation and
   asset/access inventories in `ExcludedTierIndices.json`.
3. **State/model tier:** trained adapter/model/optimizer states, foundation weights
   and state replicas are excluded. Method payload/state audit and baseline
   three-tier local availability are separately indexed; their availability
   does not grant public access or certify deterministic training replay.
4. **Gradient/timing execution tier:** stored cosine/dot/norm scalar identities
   and recorded timings are reduced, not freshly differentiated or benchmarked.
5. **Public rights/release tier:** no image, annotation or model redistribution
   rights have been established by this task. No public release, DOI/tag, cloud
   execution, submission or manuscript distribution is performed.

The baseline editorial v4 and stable alias are preserved exactly. The old strict
array-numerical failure and unresolved historical GPU-kernel discrepancy are not
waived by a successful scalar replay. This attachment adds a current statistical
tier; it does not replace earlier scientific evidence or certify full public
reproducibility. Local-only tier indices may themselves contain private paths;
their full copies are kept outside this attachment.
