"""CPU-only schema, scalar and archive negative tests; no expensive diagnostics."""
import copy
import importlib.util
import json
from pathlib import Path
import stat
import unittest
import zipfile

HERE = Path(__file__).resolve().parent


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


safe = module(HERE / 'safe_archive.py', 'safe_test')
p = module(HERE / 'code/posthoc.py', 'posthoc_test')
g = module(HERE / 'code/gradient.py', 'gradient_test')
s = module(HERE / 'code/sampling.py', 'sampling_test')
cfg = module(HERE / 'config_validate.py', 'configuration_test')


class CurrentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = json.loads((HERE / 'inputs/posthoc/AnalysisRows.json').read_bytes())['rows']
        cls.bridge = json.loads((HERE / 'inputs/posthoc/BridgeRows.json').read_bytes())['rows']
        cls.gradient = json.loads((HERE / 'inputs/gradient/Cells.json').read_bytes())

    def test_complete_672(self):
        self.assertEqual(len(p.validate_rows(self.rows)), 672)

    def test_missing_state(self):
        with self.assertRaises(ValueError): p.validate_rows(self.rows[:-1])

    def test_duplicate_unit(self):
        with self.assertRaises(ValueError): p.validate_rows(self.rows + [self.rows[0]])

    def test_missing_router_mode(self):
        with self.assertRaises(ValueError): p.validate_rows([r for r in self.rows if r['mode'] != 'calibration-mean'])

    def test_nonfinite(self):
        rows = copy.deepcopy(self.rows)
        rows[0]['metrics']['CG_l2_means_float64'] = float('nan')
        with self.assertRaises(ValueError): p.validate_rows(rows)

    def test_undefined_not_zero(self):
        x = p.describe({42:1.0,43:None,44:0.0})
        self.assertIsNone(x['mean'])
        self.assertIsNone(x['sample_sd_ddof1'])
        self.assertEqual(x['undefined_seeds'], [43])

    def test_sample_sd_and_direction(self):
        x = p.delta({42:2.,43:0.,44:1.}, {42:1.,43:1.,44:1.})
        self.assertEqual(x['mean'], 0.)
        self.assertEqual(x['sample_sd_ddof1'], 1.)
        self.assertEqual((x['positive_seeds'],x['negative_seeds'],x['zero_seeds']), (1,1,1))

    def test_complete_bridge(self):
        self.assertEqual(len(p.reduce_bridge(self.bridge)), 24)

    def test_tampered_bridge_delta(self):
        rows = copy.deepcopy(self.bridge)
        rows[0]['difference'] += 0.01
        with self.assertRaises(ValueError): p.reduce_bridge(rows)

    def test_bridge_missing_seed(self):
        with self.assertRaises(ValueError): p.reduce_bridge(self.bridge[1:])

    def test_flickr_not_testonly(self):
        with self.assertRaises(ValueError): p.validate_flickr(dict(split_counts=dict(train=473,val=20,test=19),karpathy_test_only=True))

    def test_gradient_missing_batch(self):
        x = copy.deepcopy(self.gradient)
        x['rows'].pop()
        with self.assertRaises(ValueError): g.reduce_cells(x)

    def test_gradient_cosine_operand(self):
        x = copy.deepcopy(self.gradient)
        x['rows'][0]['global_gradient']['cosine'] += 0.01
        with self.assertRaises(ValueError): g.reduce_cells(x)

    def test_paired_median_not_sum_of_medians(self):
        self.assertEqual(s.paired_total([0,5,10], [10,5,0]), 10)
        with self.assertRaises(ValueError): s.paired_total([0], [1,2])

    def test_unsafe_zip_paths(self):
        for name in ('../evil','/evil','C:/evil','a\\evil','a/../evil','a//b','a./b','NUL.txt','x:stream','a\n.txt'):
            with self.subTest(name=name), self.assertRaises(ValueError): safe.safe_names([zipfile.ZipInfo(name)])

    def test_case_collision(self):
        with self.assertRaises(ValueError): safe.safe_names([zipfile.ZipInfo('A.json'),zipfile.ZipInfo('a.json')])

    def test_prefix_collision(self):
        with self.assertRaises(ValueError): safe.safe_names([zipfile.ZipInfo('a'),zipfile.ZipInfo('a/b')])

    def test_symlink(self):
        info = zipfile.ZipInfo('link');info.external_attr = (stat.S_IFLNK | 0o777) << 16
        with self.assertRaises(ValueError): safe.safe_names([info])

    def test_expansion_bound(self):
        info = zipfile.ZipInfo('large');info.file_size = safe.MAX_MEMBER + 1
        with self.assertRaises(ValueError): safe.safe_names([info])

    def test_recorded66_config_and_manifest(self):
        self.assertEqual(cfg.validate(HERE)['yaml_files'], 66)

    def test_missing_configuration(self):
        original=cfg.read
        def tampered(path):
            value=original(path)
            if path.name=='ConfigIndex.json': value['entries'].pop()
            return value
        cfg.read=tampered
        try:
            with self.assertRaises(ValueError):cfg.validate(HERE)
        finally:cfg.read=original

    def test_no_public_state_snapshot(self):
        original=cfg.read
        def tampered(path):
            value=original(path)
            if path.name=='CheckpointManifest.json':value['public_snapshot']=True
            return value
        cfg.read=tampered
        try:
            with self.assertRaises(ValueError):cfg.validate(HERE)
        finally:cfg.read=original

    def test_yaml_semantic_tamper(self):
        original=cfg.read
        def tampered(path):
            value=original(path)
            if path.suffix=='.yaml':value['applicability']['unit']='wrong-unit'
            return value
        cfg.read=tampered
        try:
            with self.assertRaises(ValueError):cfg.validate(HERE)
        finally:cfg.read=original


if __name__ == '__main__':
    unittest.main()
