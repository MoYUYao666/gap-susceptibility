"""Standalone recorded configuration/checkpoint metadata checks; no state loading."""
import hashlib
import itertools
import json
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validate(root):
    root=Path(root)
    index=read(root/'config/ConfigIndex.json')
    expected={('scientific_core',f'{d}__{m}__s{s}') for d,m,s in itertools.product(('dtd','cifar100','food101'),('lora_text','lora_both'),(42,43,44))}
    expected|={('scientific_extension',f'{d}__{p}__{g}__s{s}') for d,p,g,s in itertools.product(('dtd','cifar100'),('early','late'),('frozen_reference','dynamic'),(42,43,44))}
    method={('methods_fixed24',f'{d}__{a}__s{s}') for d,a,s in itertools.product(('dtd','cifar100'),('router-static','router-input','rope-fixed','rope-learned'),(42,43,44))}
    keys=[(r['family'],r['unit']) for r in index['entries']]
    require(len(keys)==len(set(keys))==66 and set(keys)==expected|method,'Exactly42+24 configs')
    missing=0
    for row in index['entries']:
        a,b=read(root/row['json']),read(root/row['yaml'])
        require(a==b,'JSON-compatible YAML semantic mismatch')
        require(a['applicability']['unit']==row['unit'] and a['applicability']['public_state_snapshot'] is False,'Configuration applicability/public scope')
        require(row['actual_recorded_only'] is True,'Defaults cannot replace actual records')
        if row['family']=='methods_fixed24':
            require(digest(a['config'])==row['sanitized_config_sha256']==a['sanitized_config_sha256'],'Sanitized method config hash')
            c=a['config']; require(row['unit']==f"{c['dataset']}__{c['arm']}__s{c['seed']}",'Method run identities')
            require(a['original_config_sha256_includes_private_paths']==row['original_config_sha256'],'Original config provenance')
        else:
            require(a['recorded_identity']['unit']==row['unit'],'Core/spectral run identity')
            if row['family']=='scientific_extension':
                require('effective_configuration' not in a and row['not_recorded_fields'],'Do not invent absent spectral effective field')
                missing+=1
            else: require('effective_configuration' in a,'Recorded core effective configuration')
    require(missing==24 and len(index['unrecorded_fields'])==24,'Recorded absence must be explicit')
    checkpoints=read(root/'checkpoints/CheckpointManifest.json')
    require(checkpoints['payload_included'] is False and checkpoints['public_snapshot'] is False,'Local inventory is not public state supply')
    core=checkpoints['core_spectral'];methods=checkpoints['methods']
    require(len(core)==252 and len(methods)==144,'Checkpoint metadata counts')
    require({(r['family'],r['unit']) for r in core}==expected,'Core/spectral checkpoint applicability')
    require({(r['family'],r['unit']) for r in methods}==method,'Method checkpoint applicability')
    require(len({(r['family'],r['unit'],r['state']) for r in core})==252,'No duplicate core checkpoints')
    require(len({(r['unit'],r['state']) for r in methods})==144,'No duplicate method checkpoints')
    for family,unit in expected:
        rows=[r for r in core if (r['family'],r['unit'])==(family,unit)]
        require({r['state'] for r in rows}=={'frozen_baseline'}|{f'epoch_{e:03d}' for e in range(5)},'All six core/spectral states')
    for family,unit in method:
        rows=[r for r in methods if r['unit']==unit]
        require({r['state'] for r in rows}=={'latest'}|{f'epoch{e:03d}' for e in range(5)},'Five distinct method epoch states plus latest alias')
    for r in core+methods:
        require(r['payload_included'] is False and r['public_snapshot'] is False,'State exclusion scope')
        item=r['checkpoint'] if 'checkpoint' in r else r
        require(item['bytes']>0 and len(item['sha256'])==64,'Local checkpoint metadata fingerprint')
    return dict(status='PASS_RECORDED_CONFIG_AND_CHECKPOINT_METADATA_ONLY',core_configs=18,spectral_configs=24,method_configs=24,
        yaml_files=66,json_files=66,core_spectral_checkpoint_records=252,method_epoch_checkpoint_records=120,method_latest_alias_records=24,
        spectral_absent_effective_configuration_fields_explicit=24,state_binaries_supplied=False,state_binaries_read=False,
        public_snapshots=False,scientific_forward_resume_replay=False)
