"""Original bridge paired scalar join summary; no array-loading functions."""
import numpy as np
SEEDS = (42,43,44)

def require(ok, message):
    if not ok: raise ValueError(message)

def paired_summary(rows):
    groups={}
    for r in rows:
        key=tuple(r[k] for k in ('dataset','arm','view','metric'))
        bucket=groups.setdefault(key,{})
        require(r['seed'] not in bucket,'Duplicate paired seed')
        bucket[r['seed']]=r['difference']
    summaries=[]
    for key,values in sorted(groups.items()):
        require(set(values)==set(SEEDS),'Three paired seeds required; no dropping')
        require(all(np.isfinite(x) for x in values.values()),'Nonfinite paired difference')
        summaries.append(dict(zip(('dataset','arm','view','metric'),key),
            mean_difference=float(np.mean([values[s] for s in SEEDS])),seed_differences=values,
            positive_seeds=sum(x>0 for x in values.values()),negative_seeds=sum(x<0 for x in values.values()),
            zero_seeds=sum(x==0 for x in values.values()),statistical_unit='paired seed within fixed source',
            interpretation='Descriptive three-seed finite comparison; no pooled datasets/checkpoints or significance claim'))
    return summaries
