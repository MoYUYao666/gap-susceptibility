"""Original independent scalar reducer functions; no tensors or tau computation."""
from collections import defaultdict
import itertools
import math
import statistics

SOURCES = ('dtd','cifar100')

ARMS = ('router-static','router-input','rope-fixed','rope-learned')

SEEDS = (42,43,44)

VIEWS = (('source','calibration'),('source','test'),('imagenet','imagenet'),('flickr','flickr'))

BOUNDARIES = (
    'Statistical unit: three paired seeds within each fixed source. Sample SD uses ddof=1; '
    'population SD ddof=0 is also retained. No pooling of sources, checkpoints, directions, queries or views. '
    'All learned epoch0..4 states and separate frozen native anchors are retained; contrasts use fixed epoch4. '
    'All six arm pairs and four router mode contrasts are retained regardless of sign. '
    'Null tau is undefined, never zero; any undefined seed makes the seed aggregate undefined. '
    'No all-row tau recomputation or new bootstrap intervals in this reducer. '
    'CG_l2_means_float64 is the L2 distance of double means of saved individually normalized features, '
    'with no FP64 renormalization. Campaign canonical normalize+fsum CG is a separate estimator: never pooled, '
    'substituted, or interpreted as an exact replay. '
    'Flickr512 is a locked mixed Karpathy cohort: 473 train / 20 val / 19 test, not test-only or an official held-out benchmark. '
    'Ordinary-LoRA bridge is matched source/seed/cohort/shared optimizer recipe, not identical parameterization, '
    'initialization draws, per-parameter learning rates, or causal isolation. No bridge geometry comparison. '
    'Saved-array integrity is inherited from the independently bound all24 validation; large tensor bytes are not rehashed here.'
)

def require(ok, message):
    if not ok: raise ValueError(message)

def metric_inventory(dataset, view):
    n=512 if view=='flickr' else 1000 if view=='imagenet' else 47 if dataset=='dtd' else 100
    names={'margin_mean','margin_mass_le_0.01','margin_mass_le_0.02','top1_agreement','tau_b',
           'tau_defined_queries','tau_undefined_queries','exact_tie_query_fraction'}
    for k in (3,5,10,20,50,100):
        if k<=n:
            names.update(f'top{k}_{s}' for s in ('winner_intrusion','set_replacement','tau_b','tau_defined_queries'))
    if view=='flickr':
        names={d+'__'+m for d in ('image_to_text','text_to_image') for m in names}
        names.update(('R1_i2t','R1_t2i'))
    else: names.add('classification_accuracy')
    return names|{'CG_l2_means_float64'}

def rowkey(row):
    return tuple(row[k] for k in ('dataset','arm','seed','view','split','epoch','mode'))

def validate_rows(rows):
    expected=set()
    for d,a,s in itertools.product(SOURCES,ARMS,SEEDS):
        states=[(None,'native')]+[(e,'learned') for e in range(5)]
        if a.startswith('router'): states += [(4,'uniform'),(4,'calibration-mean')]
        expected.update((d,a,s,v,sp,e,m) for (e,m),(v,sp) in itertools.product(states,VIEWS))
    observed={}
    for i,r in enumerate(rows):
        key=rowkey(r)
        require(key in expected and key not in observed, 'Unlocked or duplicate scalar row: '+str(key))
        require(type(r['seed']) is int and (r['epoch'] is None or type(r['epoch']) is int), 'Noninteger seed/epoch')
        observed[key]=(i,r)
        require(set(r['metrics'])==metric_inventory(r['dataset'],r['view']), 'Metric inventory drift: '+str(key))
        for name,value in r['metrics'].items():
            if value is None:
                require(name.endswith('tau_b'), 'Only undefined tau may be null')
                continue
            require(type(value) in (int,float) and math.isfinite(value), 'Invalid scalar: '+name)
            if name.endswith('_queries'): require(type(value) is int and value>=0, 'Invalid query count')
            elif name.endswith('tau_b'): require(-1<=value<=1, 'Tau outside [-1,1]')
            elif name=='CG_l2_means_float64' or name.endswith('margin_mean'): require(0<=value<=2.000001, 'Invalid cosine distance/margin')
            else: require(0<=value<=1.000001, 'Fraction or cosine margin outside range')
    require(set(observed)==expected and len(rows)==672, 'Exactly 24 units / five adapted states / native / full intervention inventory required')
    return observed

def validate_flickr(provenance):
    require(provenance['split_counts']==dict(train=473,val=20,test=19) and
            provenance['karpathy_test_only'] is False, 'Flickr must be the locked mixed512 cohort, not test-only')

def describe(values):
    require(set(values)==set(SEEDS), 'Exactly three paired seeds required; no dropping')
    undefined=[s for s in SEEDS if values[s] is None]
    xs=[values[s] for s in SEEDS]
    require(all(x is None or (type(x) in (float,int) and math.isfinite(x)) for x in xs), 'Invalid finite seed values')
    return dict(n_planned=3,seed_values={str(s):values[s] for s in SEEDS},undefined_seeds=undefined,
        mean=None if undefined else statistics.fmean(xs),
        sample_sd_ddof1=None if undefined else statistics.stdev(xs),
        population_sd_ddof0=None if undefined else statistics.pstdev(xs))

def delta(left,right):
    require(set(left)==set(right)==set(SEEDS), 'Delta pairing incomplete')
    values={s:None if left[s] is None or right[s] is None else left[s]-right[s] for s in SEEDS}
    return dict(**describe(values),positive_seeds=sum(v is not None and v>0 for v in values.values()),
        zero_seeds=sum(v==0 for v in values.values()),negative_seeds=sum(v is not None and v<0 for v in values.values()))

def reduce_rows(rows):
    index=validate_rows(rows);groups=defaultdict(dict)
    for i,r in enumerate(rows):
        key=tuple(r[k] for k in ('dataset','arm','view','split','epoch','mode'))
        groups[key][r['seed']]=(i,r)
    aggregates=[];deltas=[]
    for (d,a,v,sp,e,m),seeds in groups.items():
        for metric in sorted(seeds[42][1]['metrics']):
            aggregates.append(dict(dataset=d,arm=a,view=v,split=sp,epoch=e,mode=m,metric=metric,
                statistics=describe({s:seeds[s][1]['metrics'][metric] for s in SEEDS}),
                source_rows=[f'/rows/{seeds[s][0]}/metrics/{metric}' for s in SEEDS]))
    for d,(v,sp) in itertools.product(SOURCES,VIEWS):
        contrasts=[((l,'learned'),(r,'learned')) for l,r in itertools.combinations(ARMS,2)]
        contrasts += [((a,m),(a,'learned')) for a in ARMS[:2] for m in ('uniform','calibration-mean')]
        for (la,lm),(ra,rm) in contrasts:
            for metric in sorted(metric_inventory(d,v)):
                if metric.endswith('_queries'): continue
                left={s:index[(d,la,s,v,sp,4,lm)] for s in SEEDS}
                right={s:index[(d,ra,s,v,sp,4,rm)] for s in SEEDS}
                deltas.append(dict(dataset=d,view=v,split=sp,epoch=4,left=la+'/'+lm,right=ra+'/'+rm,
                    metric=metric,direction='left_minus_right',statistics=delta(
                        {s:left[s][1]['metrics'][metric] for s in SEEDS},
                        {s:right[s][1]['metrics'][metric] for s in SEEDS}),
                    source_rows={side:[f'/rows/{pairs[s][0]}/metrics/{metric}' for s in SEEDS]
                                 for side,pairs in [('left',left),('right',right)]}))
    state_deltas=[]
    for d,a,(v,sp) in itertools.product(SOURCES,ARMS,VIEWS):
        for re,rm,label in [(None,'native','native'),(0,'learned','epoch0')]:
            for metric in sorted(metric_inventory(d,v)):
                if metric.endswith('_queries'):continue
                left={s:index[(d,a,s,v,sp,4,'learned')] for s in SEEDS}
                right={s:index[(d,a,s,v,sp,re,rm)] for s in SEEDS}
                state_deltas.append(dict(dataset=d,arm=a,view=v,split=sp,epoch=4,mode='learned',metric=metric,
                    reference_state=label,direction='epoch4_learned_minus_'+label,
                    statistics=delta({s:left[s][1]['metrics'][metric] for s in SEEDS},
                                     {s:right[s][1]['metrics'][metric] for s in SEEDS}),
                    source_rows={side:[f'/rows/{pairs[s][0]}/metrics/{metric}' for s in SEEDS]
                                 for side,pairs in [('left',left),('right',right)]}))
    return dict(aggregates=aggregates,fixed_epoch4_deltas=deltas,state_deltas=state_deltas)

def check_comparisons(summary, comparisons):
    observed={}
    for r in comparisons:
        key=(r['dataset'],r['view'],r['split'],r['left']['arm']+'/'+r['left']['mode'],
             r['right']['arm']+'/'+r['right']['mode'],r['metric'])
        require(key not in observed and r['epoch']==4 and r['difference']=='left_minus_right','Duplicate/unlocked comparison')
        observed[key]=r
    expected={(r['dataset'],r['view'],r['split'],r['left'],r['right'],r['metric']):r for r in summary['fixed_epoch4_deltas']}
    require(set(observed)==set(expected),'Analyzer comparison inventory incomplete')
    for key,r in expected.items():
        old=observed[key]['statistics'];new=r['statistics']
        mean=old['mean_difference']
        if new['mean'] is None:
            require(mean is None and old['status']=='UNDEFINED_METRIC_NO_INTERVAL','Undefined seed was dropped')
        else:
            require(type(mean) in (int,float) and math.isclose(mean,new['mean'],abs_tol=2e-15,rel_tol=1e-13), 'Analyzer scalar mean delta mismatch')
            require(old['seed_differences']==new['seed_values'],'Analyzer paired seed delta mismatch')

def reduce_bridge(rows):
    expected={(d,a,s,v,m) for d,a,s in itertools.product(SOURCES,ARMS,SEEDS)
              for v,m in [('imagenet','classification_accuracy'),('flickr','R1_i2t'),('flickr','R1_t2i')]}
    observed=set();groups=defaultdict(dict)
    for i,r in enumerate(rows):
        key=tuple(r[k] for k in ('dataset','arm','seed','view','metric'))
        require(key in expected and key not in observed,'Bridge row inventory mismatch')
        observed.add(key)
        require(r['epoch']==4 and r['mode']=='learned' and r['difference_direction']=='method_minus_ordinary_lora','Bridge contrast changed')
        for name in ('method_value','ordinary_lora_value'):
            require(type(r[name]) in (float,int) and math.isfinite(r[name]) and 0<=r[name]<=1,'Invalid finite bridge performance')
        require(r['difference']==r['method_value']-r['ordinary_lora_value'],'Bridge delta arithmetic mismatch')
        groups[(r['dataset'],r['arm'],r['view'],r['metric'])][r['seed']]=(i,r)
    require(observed==expected and len(rows)==72,'Exactly72 full bridge metric rows required')
    result=[]
    for (d,a,v,m),seeds in sorted(groups.items()):
        left={s:seeds[s][1]['method_value'] for s in SEEDS};right={s:seeds[s][1]['ordinary_lora_value'] for s in SEEDS}
        result.append(dict(dataset=d,arm=a,view=v,metric=m,method=describe(left),ordinary_lora=describe(right),
            difference=delta(left,right),direction='method_minus_ordinary_lora',
            source_rows=[f'/rows/{seeds[s][0]}' for s in SEEDS]))
    return result
