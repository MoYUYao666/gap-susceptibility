"""Portable saved-scalar replay only; never loads torch, models or images."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics
import numpy as np

METHODS=('fullsort','directtop2','blockexact4096')
METRICS=('winner_agreement','winner_margin','winner_margin_mass_0.01','winner_margin_mass_0.02',
         'tau_b_at_5','winner_intrusion_at_5','tau_b_at_100','winner_intrusion_at_100')


def require(ok,message):
    if not ok:raise ValueError(message)


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def pointer(value,path):
    for k in path.strip('/').split('/'):
        value=value[int(k)] if isinstance(value,list) else value[k]
    return value


def display(value,transform,digits):
    require(transform in ('identity','milliseconds'),'Unknown presentation transform')
    return f'{value*(1000 if transform=="milliseconds" else 1):.{digits}f}'


def check_query_stat(x,repetitions):
    require(len(x['draw_estimates'])==len(x['draw_defined'])==repetitions,'Missing query draw')
    require(x['population_defined']+x['population_undefined']==x['population_rows'],'Wrong population accounting')
    usable=np.array([v for v in x['draw_estimates'] if v is not None],dtype=float)
    require(np.isfinite(usable).all(),'Nonfinite scalar estimate')
    require(x['defined_draws']==len(usable),'Defined draw count drift')
    require(all((v is None)==(n==0) for v,n in zip(x['draw_estimates'],x['draw_defined'])),'Undefined draw imputation')
    if len(usable):
        require(x['full_population_mean'] is not None,'Defined draw without population mean')
        errors=usable-x['full_population_mean']
        expected=dict(mean_signed_error=float(errors.mean()),mean_absolute_error=float(np.abs(errors).mean()),
            absolute_error_p95=float(np.quantile(np.abs(errors),.95)),
            empirical_estimate_range_025_975=np.quantile(usable,[.025,.975]).tolist())
    else:expected=dict.fromkeys(('mean_signed_error','mean_absolute_error','absolute_error_p95','empirical_estimate_range_025_975'))
    for k,v in expected.items():require(x[k]==v,'Saved query reduction drift '+k)


def query_rows(summary):
    require(summary['design']==dict(budgets=[32,64,128,256,512,1024],repetitions=50,seed=20261124),'Query design changed')
    require([x['condition'] for x in summary['conditions']]==[f'dense_{i:02d}' for i in range(29)]+[f'prompt_{i:02d}' for i in range(10)],'Condition inventory/order drift')
    out=[]
    for i,condition in enumerate(summary['conditions']):
        require(set(condition['budgets'])=={str(b) for b in summary['design']['budgets']},'Missing/extra budget')
        for budget,values in condition['budgets'].items():
            require(set(values)==set(METRICS),'Metric inventory drift')
            for metric,x in values.items():
                check_query_stat(x,50)
                require(x['population_rows']==5000,'Wrong finite query population')
                out.append(dict(condition=condition['condition'],queries=int(budget),metric=metric,
                    population_rows=x['population_rows'],population_defined=x['population_defined'],population_undefined=x['population_undefined'],
                    full_population_mean=x['full_population_mean'],defined_draws=x['defined_draws'],mean_signed_error=x['mean_signed_error'],
                    mean_absolute_error=x['mean_absolute_error'],absolute_error_p95=x['absolute_error_p95'],
                    estimate_p025=x['empirical_estimate_range_025_975'][0] if x['empirical_estimate_range_025_975'] else None,
                    estimate_p975=x['empirical_estimate_range_025_975'][1] if x['empirical_estimate_range_025_975'] else None,
                    pointer=f'/conditions/{i}/budgets/{budget}/{metric}'))
    return out


def worst_rows(conditions,budgets,metrics):
    out=[]
    for b in budgets:
        for metric in metrics:
            values=[(c['budgets'][str(b)][metric]['absolute_error_p95'],i,c['condition']) for i,c in enumerate(conditions)]
            require(all(v is not None and np.isfinite(v) for v,i,n in values),'Undefined sampling tail; do not impute')
            value,i,name=max(values,key=lambda t:t[0])
            out.append(dict(queries=b,metric=metric,value=value,condition=name,
                pointer=f'/conditions/{i}/budgets/{b}/{metric}/absolute_error_p95',
                interpretation='Maximum across fixed conditions of empirical within-condition p95 absolute sampling error; not a population CI'))
    return out


def paired_total(shared,readout):
    require(len(shared)==len(readout)>0,'Unpaired workflow timings')
    return statistics.median(a+b for a,b in zip(shared,readout))


def check_cost_record(record):
    values=record['readouts']
    require(len(values)==3 and {v['method'] for v in values}==set(METHODS),'Missing/duplicate exact readout')
    require(len({v['equality_sha256'] for v in values})==1,'Readout equality receipts disagree')
    for v in values:
        require(v['readout_seconds']>=0 and np.isfinite(v['readout_seconds']),'Invalid readout timing')
        require(v['constructed_shared_plus_readout_seconds']==record['shared_wall_seconds']+v['readout_seconds'],'Unpaired constructed sum')


def cost_rows(result):
    require(result['design']['budgets']==[64,256,1024,5000],'Cost budgets drift')
    require(len(result['records'])==36,'Missing/extra timing pass')
    for row in result['records']:check_cost_record(row)
    out=[]
    for budget in result['design']['budgets']:
        records=[x for x in result['records'] if x['budget']==budget]
        require(len(records)==9 and {x['round'] for x in records}==set(range(9)),'Incomplete per-budget rounds')
        require(all(x['warmup']==(x['round']<2) for x in records),'Warmup/trial mixture')
        records=[x for x in records if not x['warmup']]
        require(len(records)==7,'Wrong trial count')
        for method in METHODS:
            shared=[x['shared_wall_seconds'] for x in records]
            times=[next(y['readout_seconds'] for y in x['readouts'] if y['method']==method) for x in records]
            out.append(dict(queries=budget,method=method,shared_median_seconds=statistics.median(shared),
                readout_median_seconds=statistics.median(times),constructed_total_median_seconds=paired_total(shared,times)))
    return out


def csv_check(path,expected):
    with Path(path).open(encoding='utf-8',newline='') as f:actual=list(csv.DictReader(f))
    norm=lambda r:{k:'' if v is None else str(v) for k,v in r.items()}
    require(actual==[norm(r) for r in expected],'Derived CSV drift '+str(path))


def verify(root):
    root=Path(root)
    manifest=read(root/'Manifest.json')
    for name,v in manifest['files'].items():
        path=root/name
        require(path.resolve().is_relative_to(root.resolve()),'Unsafe companion member')
        require(path.stat().st_size==v['bytes'] and sha(path)==v['sha256'],'Companion member drift '+name)
    q=read(root/'QuerySummary.json');c=read(root/'CostResults.json');review=read(root/'CostScientificReview.json')
    qr=query_rows(q);cr=cost_rows(c);wr=worst_rows(q['conditions'],q['design']['budgets'],METRICS)
    csv_check(root/'QueryReadouts.csv',qr);csv_check(root/'QueryWorstErrors.csv',wr);csv_check(root/'CostReadouts.csv',cr)
    for row in cr:
        official=next(x for x in review['budgets'] if x['queries']==row['queries'])
        for key,value in [('shared_median_seconds',official['shared_wall_median_seconds']),
            ('readout_median_seconds',official['readout_median_seconds'][row['method']]),
            ('constructed_total_median_seconds',official['constructed_total_median_seconds'][row['method']])]:
            require(row[key]==value,'Accepted cost summary drift')
    sources={}
    for b in read(root/'NumericBindings.json'):
        if b['local_archive'] not in sources:sources[b['local_archive']]=read(root/b['local_archive'])
        value=pointer(sources[b['local_archive']],b['pointer'])
        require(value==b['value'],'Named numeric binding drift '+b['name'])
        if b['digits'] is not None:require(display(value,b['transform'],b['digits'])==b['display'],'Display rounding drift '+b['name'])
    return dict(status='PASS_PORTABLE_SAVED_SCALAR_REPLAY_ONLY',query_stat_rows=len(qr),query_draw_values=39*6*50*8,
        cost_passes=len(c['records']),cost_readouts=len(c['records'])*3,full_model_inference=False,
        original_row_metric_regeneration=False,population_confidence_intervals=False,
        constructed_totals='Median of paired shared-plus-readout sums; not sum of medians or three independent workflows')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
    print(json.dumps(verify(a.root),indent=2))
