"""Exact selected finite scalar reductions; not a gradient/autograd recomputation."""
import math
from fractions import Fraction
from decimal import Decimal, localcontext

def require(ok,msg):
    if not ok:raise ValueError(msg)

def fraction(row):return Fraction(int(row['preservation_exact_numerator']),int(row['preservation_exact_denominator']))

def decimal_fraction(x):
    with localcontext() as ctx:
        ctx.prec=130
        return str(Decimal(x.numerator)/Decimal(x.denominator))

def reduce_cells(ledger):
    rows=ledger['rows']
    require(len(rows)==48,'Expected finite48 ledger')
    expected={(s,i,e,b) for s in ['dtd','cifar100'] for i in [42,43,44] for e in [1,4] for b in range(4)}
    actual=[(r['cell']['source'],r['cell']['seed'],r['cell']['epoch'],r['cell']['batch']) for r in rows]
    require(len(set(actual))==48 and set(actual)==expected,'Missing, duplicate or mismatched cell')
    groups=[]
    with localcontext() as ctx:
        ctx.prec=130
        for source in ['dtd','cifar100']:
            for seed in [42,43,44]:
                epochs={}
                for epoch in [1,4]:
                    indices=[i for i,r in enumerate(rows) if (r['cell']['source'],r['cell']['seed'],r['cell']['epoch'])==(source,seed,epoch)]
                    subset=[rows[i] for i in indices]
                    require(len(subset)==4 and {r['cell']['batch'] for r in subset}==set(range(4)),'Nested batches')
                    for r in subset:
                        require(len(r['row_ids'])==len(r['labels'])==32,'Row/label lengths')
                        g=r['global_gradient'];a,b=g['norm_ce'],g['norm_preservation']
                        require(all(math.isfinite(g[k]) for k in ['dot','norm_ce','norm_preservation']) and a>=0 and b>=0,'Finite nonnegative norms')
                        if a==0 or b==0:require(g['cosine'] is None and g['status']=='UNDEFINED_ZERO_NORM','Zero norms are undefined')
                        else:require(g['status']=='DEFINED' and g['cosine']==g['dot']/(a*b),'Cosine identity')
                    mse=sum((fraction(r) for r in subset),Fraction(0))/4
                    cosine=[r['global_gradient']['cosine'] for r in subset if r['global_gradient']['cosine'] is not None]
                    epochs[str(epoch)]=dict(ledger_indices=indices,
                        DecimalCE=str(sum((Decimal(r['DecimalCE']) for r in subset),Decimal(0))/4),
                        preservation_numerator=str(mse.numerator),preservation_denominator=str(mse.denominator),
                        preservation=decimal_fraction(mse),negative=sum(x<0 for x in cosine),defined=len(cosine))
                mse_delta=Fraction(int(epochs['4']['preservation_numerator']),int(epochs['4']['preservation_denominator']))-Fraction(int(epochs['1']['preservation_numerator']),int(epochs['1']['preservation_denominator']))
                groups.append(dict(source=source,seed=seed,epochs=epochs,
                    CE_delta=str(Decimal(epochs['4']['DecimalCE'])-Decimal(epochs['1']['DecimalCE'])),
                    MSE_delta=decimal_fraction(mse_delta),MSE_delta_numerator=str(mse_delta.numerator),MSE_delta_denominator=str(mse_delta.denominator)))
    cos=[r['global_gradient']['cosine'] for r in rows if r['global_gradient']['cosine'] is not None]
    counts=rows[0]['counts']
    require(all(r['counts']['parameter_pairs']==144 and r['counts']['shared_A_pairs']==72 and r['counts']['B_head_pairs']==720 for r in rows),'Gradient inventory')
    return dict(groups=groups,design=dict(batches=48,batch_rows=32,training_units=6,batches_per_epoch=4,epochs=[1,4],
        parameter_tensors=144,shared_A=72,B_head_slices=720,undefined=sum(r['counts']['undefined_zero_norm'] for r in rows)),
        global_cosine=dict(negative=sum(x<0 for x in cos),defined=len(cos),minimum=min(cos),maximum=max(cos)))
