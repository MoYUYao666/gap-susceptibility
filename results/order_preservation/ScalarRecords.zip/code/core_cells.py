"""Original source-local scalar reporting functions, exact extracted bodies."""
import hashlib
from pathlib import Path
import numpy as np

DATASETS = ('dtd', 'cifar100', 'food101')

MODES = ('lora_text', 'lora_both')

SEEDS = (42, 43, 44)

TABLE_SCALARS = (
    'correlation/imagenet/accuracy/same_view/rho_tau',
    'correlation/imagenet/accuracy/same_view/rho_gap',
    'correlation/imagenet/accuracy/same_view/abs_rho_tau_minus_abs_rho_gap',
    'regret_difference/imagenet/accuracy/min_winner_mass_0.01_minus_last',
    'regret_difference/imagenet/accuracy/min_winner_mass_0.02_minus_last',
)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def _pointer(path, tokens, digest=None):
    result = dict(path=str(Path(path).resolve()), json_pointer='/' + '/'.join(
        str(k).replace('~', '~0').replace('/', '~1') for k in tokens))
    if digest is not None:
        result['sha256'] = digest
    return result

def _undefined_evidence(row, name):
    parts = name.split('/')
    if parts[0] == 'correlation':
        evidence = row['correlations'][parts[1]][parts[2]][parts[3]]
        fields = (['tau_undefined_reason'] if parts[4] == 'rho_tau' else
                  ['gap_undefined_reason'] if parts[4] == 'rho_gap' else
                  ['tau_undefined_reason', 'gap_undefined_reason'])
        reason = '; '.join(str(evidence[k]) for k in fields if evidence.get(k))
        return reason or 'Undefined inherited scalar; no seed dropping', ['correlations'] + parts[1:4]
    selector = parts[3].split('_minus_')[0]
    reason = row['choices'].get(selector, {}).get('reason')
    return reason or 'Undefined inherited selector/scalar; no seed dropping', ['outcomes'] + parts[1:3]

def _estimate(values, samples):
    finite = np.isfinite(values)
    complete = bool(finite.all())
    return dict(estimate=float(values.mean()) if complete else None,
        interval95=np.percentile(samples, [2.5, 97.5]).tolist() if complete else None,
        complete=complete, finite_seeds=int(finite.sum()), required_seeds=3,
        constant_seed_values=bool(np.ptp(values) == 0) if complete else None,
        reason=None if complete else 'Undefined source-local seed; no dropping or imputation')

def cell_panel(trajectories, original_summary, bundle, output):
    """Only inherited scalars; joint source-local draws exactly match the core RNG."""
    indexed = {(r['cell']['dataset'], r['cell']['mode'], r['cell']['seed']): (i, r)
               for i, r in enumerate(trajectories)}
    expected = {(d, m, s) for d in DATASETS for m in MODES for s in SEEDS}
    require(len(trajectories) == 18 and set(indexed) == expected, 'Exact paired18 scalar panel required')
    names = sorted(trajectories[0]['scalar_estimands'])
    require(all(sorted(r['scalar_estimands']) == names for r in trajectories), 'Incomplete scalar schema')
    source_file = bundle / 'Trajectories.json'
    source_sha = core.digest(source_file)
    cells_file = output / 'Cells.json'
    rng = np.random.default_rng(20261121)
    cells, contrasts, hashes = [], [], {}
    for dataset in DATASETS:
        indices = rng.integers(3, size=(20000, 3))
        hashes[dataset] = hashlib.sha256(indices.astype('<i8').tobytes()).hexdigest()
        require(hashes[dataset] == original_summary['draw_sha256_by_dataset'][dataset], 'Original source draw SHA mismatch')
        weights = np.stack([(indices == j).sum(axis=1) for j in range(3)], axis=1) / 3
        source = np.array([[[indexed[dataset, mode, seed][1]['scalar_estimands'][name]
                            for name in names] for mode in MODES] for seed in SEEDS], dtype=float)
        # Same count/einsum arithmetic as summarize_panel, with one fixed source.
        samples = np.einsum('rs,smf->rmf', weights, source)
        source_cells = []
        for mode_index, mode in enumerate(MODES):
            cell_index = len(cells)
            estimands = {}
            for j, name in enumerate(names):
                seed_rows = []
                for seed in SEEDS:
                    index, row = indexed[dataset, mode, seed]
                    value = row['scalar_estimands'][name]
                    reason, evidence = _undefined_evidence(row, name)
                    seed_rows.append(dict(seed=seed, unit=row['cell']['id'], value=value,
                        reason=reason if value is None else None,
                        value_pointer=_pointer(source_file, ['trajectories', index, 'scalar_estimands', name], source_sha),
                        evidence_pointer=_pointer(source_file, ['trajectories', index] + evidence, source_sha)))
                stat = _estimate(source[:, mode_index, j], samples[:, mode_index, j])
                prefix = ['cells', cell_index, 'estimands', name]
                stat.update(seed_values=seed_rows,
                    estimate_pointer=_pointer(cells_file, prefix + ['estimate']),
                    interval_pointer=_pointer(cells_file, prefix + ['interval95']))
                estimands[name] = stat
            cell = dict(dataset=dataset, mode=mode, seeds=list(SEEDS), estimands=estimands)
            cells.append(cell); source_cells.append(cell)
        estimands = {}
        for j, name in enumerate(names):
            values = source[:, 1, j] - source[:, 0, j]
            stat = _estimate(values, samples[:, 1, j] - samples[:, 0, j])
            prefix = ['source_contrasts', len(contrasts), 'estimands', name]
            pairs = []
            for i, seed in enumerate(SEEDS):
                left = source_cells[0]['estimands'][name]['seed_values'][i]
                right = source_cells[1]['estimands'][name]['seed_values'][i]
                difference = None if left['value'] is None or right['value'] is None else right['value'] - left['value']
                pairs.append(dict(seed=seed, left=left['value'], right=right['value'], difference=difference,
                    reason=None if difference is not None else 'Undefined paired source seed; no seed dropping',
                    left_pointer=left['value_pointer'], right_pointer=right['value_pointer'],
                    difference_pointer=_pointer(cells_file, prefix + ['paired_seed_values', i, 'difference'])))
            stat.update(paired_seed_values=pairs, finite_cells=int(np.isfinite(source[:, :, j]).sum()), required_cells=6,
                estimate_pointer=_pointer(cells_file, prefix + ['estimate']),
                interval_pointer=_pointer(cells_file, prefix + ['interval95']))
            estimands[name] = stat
        contrasts.append(dict(dataset=dataset, left=MODES[0], right=MODES[1],
                              direction='lora_both minus lora_text', seeds=list(SEEDS), estimands=estimands))
    tables = []
    for name in TABLE_SCALARS:
        seed_rows, cell_rows, contrast_rows = [], [], []
        for cell in cells:
            stat = cell['estimands'][name]
            seed_rows += [dict(dataset=cell['dataset'], mode=cell['mode'], **r) for r in stat['seed_values']]
            cell_rows.append(dict(dataset=cell['dataset'], mode=cell['mode'],
                **{k: stat[k] for k in ('estimate', 'interval95', 'estimate_pointer', 'interval_pointer', 'reason')},
                input_pointers=[r['value_pointer'] for r in stat['seed_values']]))
        for contrast in contrasts:
            stat = contrast['estimands'][name]
            contrast_rows.append(dict(dataset=contrast['dataset'], direction=contrast['direction'],
                **{k: stat[k] for k in ('estimate', 'interval95', 'estimate_pointer', 'interval_pointer', 'reason')},
                input_pointers=[p for r in stat['paired_seed_values'] for p in (r['left_pointer'], r['right_pointer'])]))
        tables.append(dict(scalar=name, units='regret percentage points' if name.startswith('regret') else 'signed correlation or absolute-strength difference',
                           seeds=seed_rows, cells=cell_rows, source_contrasts=contrast_rows))
    return dict(cells=cells, source_contrasts=contrasts, draw_sha256_by_dataset=hashes, tables=tables)
