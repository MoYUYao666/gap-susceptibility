"""Independent standard-library scalar reduction; never loads tensors or recomputes tau."""
import argparse
from collections import defaultdict
import datetime
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
W = HERE.parents[2]
PLAN = W/'methods/PosthocMatrix_E_v3.json'
PLAN_SHA = 'dcc1bf3dc99e62f43cfaa569971b472839fb58e5bc71c983dea0985631713591'
ANALYSIS = Path('EXCLUDED_LOCAL_ANALYSIS.json')
SOURCES = ('dtd','cifar100')
ARMS = ('router-static','router-input','rope-fixed','rope-learned')
SEEDS = (42,43,44)
VIEWS = (('source','calibration'),('source','test'),('imagenet','imagenet'),('flickr','flickr'))
COMPLETE = 'FULL24_CPU_POSTHOC_ANALYSIS_COMPLETE_PENDING_SCIENTIFIC_REVIEW'
BOUNDARIES = (
    'Statistical unit: three paired seeds within each fixed source. Sample SD uses ddof=1; '
    'population SD ddof=0 is also retained. No pooling of sources, checkpoints, directions, queries or views. '
    'All learned epoch0..4 states and separate frozen native anchors are retained; contrasts use fixed epoch4. '
    'All six arm pairs and four router mode contrasts are retained regardless of sign. '
    'Null tau is undefined, never zero; any undefined seed makes the seed aggregate undefined. '
    'No all-row tau recomputation or new bootstrap intervals in this reducer. '
    'CG_l2_means_float64 is the L2 distance of double means of saved individually normalized features, '
    'with no FP64 renormalization. Campaign canonical normalize+fsum CG is a separate estimator: never pooled, '
    'substituted, or interpreted as an exact replay. '
    'Flickr512 is a locked mixed Karpathy cohort: 473 train / 20 val / 19 test, not test-only or an official held-out benchmark. '
    'Ordinary-LoRA bridge is matched source/seed/cohort/shared optimizer recipe, not identical parameterization, '
    'initialization draws, per-parameter learning rates, or causal isolation. No bridge geometry comparison. '
    'Saved-array integrity is inherited from the independently bound all24 validation; large tensor bytes are not rehashed here.'
)


def require(ok, message):
    if not ok: raise ValueError(message)


def decode(data):
    def pairs(items):
        out={}
        for k,v in items:
            require(k not in out, 'Duplicate JSON key: '+k)
            out[k]=v
        return out
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('Nonfinite JSON: '+s)))


def record(path, data=None):
    path=Path(path).resolve()
    data=path.read_bytes() if data is None else data
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def checked(entry):
    require(record(entry['path'])==entry, 'Source size/SHA mismatch: '+entry['path'])
    return Path(entry['path'])


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def read_committed(path):
    path=Path(path); marker=path.with_suffix('.sha256')
    require(path.is_file() and marker.is_file(), 'Analysis.json AND Analysis.sha256 must be committed')
    before=(path.stat().st_size,path.stat().st_mtime_ns)
    data=path.read_bytes()  # Exactly one read of the actual analysis bytes in this reducer.
    identity=record(path,data)
    require(marker.read_text(encoding='ascii').strip()==identity['sha256'], 'Committed analysis SHA mismatch')
    require(before==(path.stat().st_size,path.stat().st_mtime_ns), 'Analysis changed while reading')
    return decode(data),identity


def expected_artifacts(arm):
    result={('native',None,'native',v) for v in ('source','imagenet','flickr')}
    result.update(('adapted',e,'learned',v) for e in range(5) for v in ('source','imagenet','flickr'))
    if arm.startswith('router'):
        result.update(('adapted',4,m,v) for m in ('uniform','calibration-mean') for v in ('source','imagenet','flickr'))
        result.add(('calibration_routes',None,None,None))
    return result


def metric_inventory(dataset, view):
    n=512 if view=='flickr' else 1000 if view=='imagenet' else 47 if dataset=='dtd' else 100
    names={'margin_mean','margin_mass_le_0.01','margin_mass_le_0.02','top1_agreement','tau_b',
           'tau_defined_queries','tau_undefined_queries','exact_tie_query_fraction'}
    for k in (3,5,10,20,50,100):
        if k<=n:
            names.update(f'top{k}_{s}' for s in ('winner_intrusion','set_replacement','tau_b','tau_defined_queries'))
    if view=='flickr':
        names={d+'__'+m for d in ('image_to_text','text_to_image') for m in names}
        names.update(('R1_i2t','R1_t2i'))
    else: names.add('classification_accuracy')
    return names|{'CG_l2_means_float64'}


def rowkey(row):
    return tuple(row[k] for k in ('dataset','arm','seed','view','split','epoch','mode'))


def validate_rows(rows):
    expected=set()
    for d,a,s in itertools.product(SOURCES,ARMS,SEEDS):
        states=[(None,'native')]+[(e,'learned') for e in range(5)]
        if a.startswith('router'): states += [(4,'uniform'),(4,'calibration-mean')]
        expected.update((d,a,s,v,sp,e,m) for (e,m),(v,sp) in itertools.product(states,VIEWS))
    observed={}
    for i,r in enumerate(rows):
        key=rowkey(r)
        require(key in expected and key not in observed, 'Unlocked or duplicate scalar row: '+str(key))
        require(type(r['seed']) is int and (r['epoch'] is None or type(r['epoch']) is int), 'Noninteger seed/epoch')
        observed[key]=(i,r)
        require(set(r['metrics'])==metric_inventory(r['dataset'],r['view']), 'Metric inventory drift: '+str(key))
        for name,value in r['metrics'].items():
            if value is None:
                require(name.endswith('tau_b'), 'Only undefined tau may be null')
                continue
            require(type(value) in (int,float) and math.isfinite(value), 'Invalid scalar: '+name)
            if name.endswith('_queries'): require(type(value) is int and value>=0, 'Invalid query count')
            elif name.endswith('tau_b'): require(-1<=value<=1, 'Tau outside [-1,1]')
            elif name=='CG_l2_means_float64' or name.endswith('margin_mean'): require(0<=value<=2.000001, 'Invalid cosine distance/margin')
            else: require(0<=value<=1.000001, 'Fraction or cosine margin outside range')
    require(set(observed)==expected and len(rows)==672, 'Exactly 24 units / five adapted states / native / full intervention inventory required')
    return observed


def validate_flickr(provenance):
    require(provenance['split_counts']==dict(train=473,val=20,test=19) and
            provenance['karpathy_test_only'] is False, 'Flickr must be the locked mixed512 cohort, not test-only')


def describe(values):
    require(set(values)==set(SEEDS), 'Exactly three paired seeds required; no dropping')
    undefined=[s for s in SEEDS if values[s] is None]
    xs=[values[s] for s in SEEDS]
    require(all(x is None or (type(x) in (float,int) and math.isfinite(x)) for x in xs), 'Invalid finite seed values')
    return dict(n_planned=3,seed_values={str(s):values[s] for s in SEEDS},undefined_seeds=undefined,
        mean=None if undefined else statistics.fmean(xs),
        sample_sd_ddof1=None if undefined else statistics.stdev(xs),
        population_sd_ddof0=None if undefined else statistics.pstdev(xs))


def delta(left,right):
    require(set(left)==set(right)==set(SEEDS), 'Delta pairing incomplete')
    values={s:None if left[s] is None or right[s] is None else left[s]-right[s] for s in SEEDS}
    return dict(**describe(values),positive_seeds=sum(v is not None and v>0 for v in values.values()),
        zero_seeds=sum(v==0 for v in values.values()),negative_seeds=sum(v is not None and v<0 for v in values.values()))


def reduce_rows(rows):
    index=validate_rows(rows);groups=defaultdict(dict)
    for i,r in enumerate(rows):
        key=tuple(r[k] for k in ('dataset','arm','view','split','epoch','mode'))
        groups[key][r['seed']]=(i,r)
    aggregates=[];deltas=[]
    for (d,a,v,sp,e,m),seeds in groups.items():
        for metric in sorted(seeds[42][1]['metrics']):
            aggregates.append(dict(dataset=d,arm=a,view=v,split=sp,epoch=e,mode=m,metric=metric,
                statistics=describe({s:seeds[s][1]['metrics'][metric] for s in SEEDS}),
                source_rows=[f'/rows/{seeds[s][0]}/metrics/{metric}' for s in SEEDS]))
    for d,(v,sp) in itertools.product(SOURCES,VIEWS):
        contrasts=[((l,'learned'),(r,'learned')) for l,r in itertools.combinations(ARMS,2)]
        contrasts += [((a,m),(a,'learned')) for a in ARMS[:2] for m in ('uniform','calibration-mean')]
        for (la,lm),(ra,rm) in contrasts:
            for metric in sorted(metric_inventory(d,v)):
                if metric.endswith('_queries'): continue
                left={s:index[(d,la,s,v,sp,4,lm)] for s in SEEDS}
                right={s:index[(d,ra,s,v,sp,4,rm)] for s in SEEDS}
                deltas.append(dict(dataset=d,view=v,split=sp,epoch=4,left=la+'/'+lm,right=ra+'/'+rm,
                    metric=metric,direction='left_minus_right',statistics=delta(
                        {s:left[s][1]['metrics'][metric] for s in SEEDS},
                        {s:right[s][1]['metrics'][metric] for s in SEEDS}),
                    source_rows={side:[f'/rows/{pairs[s][0]}/metrics/{metric}' for s in SEEDS]
                                 for side,pairs in [('left',left),('right',right)]}))
    state_deltas=[]
    for d,a,(v,sp) in itertools.product(SOURCES,ARMS,VIEWS):
        for re,rm,label in [(None,'native','native'),(0,'learned','epoch0')]:
            for metric in sorted(metric_inventory(d,v)):
                if metric.endswith('_queries'):continue
                left={s:index[(d,a,s,v,sp,4,'learned')] for s in SEEDS}
                right={s:index[(d,a,s,v,sp,re,rm)] for s in SEEDS}
                state_deltas.append(dict(dataset=d,arm=a,view=v,split=sp,epoch=4,mode='learned',metric=metric,
                    reference_state=label,direction='epoch4_learned_minus_'+label,
                    statistics=delta({s:left[s][1]['metrics'][metric] for s in SEEDS},
                                     {s:right[s][1]['metrics'][metric] for s in SEEDS}),
                    source_rows={side:[f'/rows/{pairs[s][0]}/metrics/{metric}' for s in SEEDS]
                                 for side,pairs in [('left',left),('right',right)]}))
    return dict(aggregates=aggregates,fixed_epoch4_deltas=deltas,state_deltas=state_deltas)


def check_comparisons(summary, comparisons):
    observed={}
    for r in comparisons:
        key=(r['dataset'],r['view'],r['split'],r['left']['arm']+'/'+r['left']['mode'],
             r['right']['arm']+'/'+r['right']['mode'],r['metric'])
        require(key not in observed and r['epoch']==4 and r['difference']=='left_minus_right','Duplicate/unlocked comparison')
        observed[key]=r
    expected={(r['dataset'],r['view'],r['split'],r['left'],r['right'],r['metric']):r for r in summary['fixed_epoch4_deltas']}
    require(set(observed)==set(expected),'Analyzer comparison inventory incomplete')
    for key,r in expected.items():
        old=observed[key]['statistics'];new=r['statistics']
        mean=old['mean_difference']
        if new['mean'] is None:
            require(mean is None and old['status']=='UNDEFINED_METRIC_NO_INTERVAL','Undefined seed was dropped')
        else:
            require(type(mean) in (int,float) and math.isclose(mean,new['mean'],abs_tol=2e-15,rel_tol=1e-13), 'Analyzer scalar mean delta mismatch')
            require(old['seed_differences']==new['seed_values'],'Analyzer paired seed delta mismatch')


def reduce_bridge(rows):
    expected={(d,a,s,v,m) for d,a,s in itertools.product(SOURCES,ARMS,SEEDS)
              for v,m in [('imagenet','classification_accuracy'),('flickr','R1_i2t'),('flickr','R1_t2i')]}
    observed=set();groups=defaultdict(dict)
    for i,r in enumerate(rows):
        key=tuple(r[k] for k in ('dataset','arm','seed','view','metric'))
        require(key in expected and key not in observed,'Bridge row inventory mismatch')
        observed.add(key)
        require(r['epoch']==4 and r['mode']=='learned' and r['difference_direction']=='method_minus_ordinary_lora','Bridge contrast changed')
        for name in ('method_value','ordinary_lora_value'):
            require(type(r[name]) in (float,int) and math.isfinite(r[name]) and 0<=r[name]<=1,'Invalid finite bridge performance')
        require(r['difference']==r['method_value']-r['ordinary_lora_value'],'Bridge delta arithmetic mismatch')
        groups[(r['dataset'],r['arm'],r['view'],r['metric'])][r['seed']]=(i,r)
    require(observed==expected and len(rows)==72,'Exactly72 full bridge metric rows required')
    result=[]
    for (d,a,v,m),seeds in sorted(groups.items()):
        left={s:seeds[s][1]['method_value'] for s in SEEDS};right={s:seeds[s][1]['ordinary_lora_value'] for s in SEEDS}
        result.append(dict(dataset=d,arm=a,view=v,metric=m,method=describe(left),ordinary_lora=describe(right),
            difference=delta(left,right),direction='method_minus_ordinary_lora',
            source_rows=[f'/rows/{seeds[s][0]}' for s in SEEDS]))
    return result


def render_bridge(rows):
    lines=['# Exact-cohort ordinary-LoRA bridge review','',BOUNDARIES,'',
        'Values and paired deltas are fractions; SD is across three source-matched seeds, ddof=1. '
        'The source for all row pointers is the bound Bridge.json. All 24 fixed cells are retained.','',
        '| Source | View | Arm | Metric | Method mean +/- SD | Ordinary mean +/- SD | Paired delta +/- SD | + / 0 / - | Source rows |',
        '|---|---|---|---|---:|---:|---:|---|---|']
    for r in rows:
        l=r['method'];b=r['ordinary_lora'];d=r['difference']
        lines.append(f"| {r['dataset']} | {r['view']} | {r['arm']} | {r['metric']} | {fmt(l['mean'])} +/- {fmt(l['sample_sd_ddof1'])} | {fmt(b['mean'])} +/- {fmt(b['sample_sd_ddof1'])} | {fmt(d['mean'])} +/- {fmt(d['sample_sd_ddof1'])} | {d['positive_seeds']} / {d['zero_seeds']} / {d['negative_seeds']} | {', '.join(r['source_rows'])} |")
    return '\n'.join(lines)+'\n'


def authenticate():
    plan_record=record(PLAN);require(plan_record['sha256']==PLAN_SHA,'Fixed plan drift')
    plan=decode(PLAN.read_bytes());sources={'plan':plan_record}
    expected={(d,a,s) for d,a,s in itertools.product(SOURCES,ARMS,SEEDS)}
    keys=[(u['dataset'],u['arm'],u['seed']) for u in plan['units']]
    require(len(keys)==24 and set(keys)==expected,'Plan is not exact fixed24')
    for name,r in plan['producers'].items(): checked(r);sources[name]=r
    latest=W/'sweeps_review/methods/posthoc_light_all24_v1/LatestDelivery.json'
    sources['saved_array_index']=record(latest)
    delivery_record=decode(latest.read_bytes());light=decode(checked(delivery_record).read_bytes())
    require(light['status']=='ALL24_INDEPENDENT_SAVED_ARRAYS_ACCEPTED_NO_MODEL_FORWARD' and
            light['accepted_units']==24 and set(light['accepted'])=={u['unit'] for u in plan['units']},'Full saved-array validation missing')
    require(light['source_records']['matrix']==plan_record,'Saved-array validation bound to another matrix')
    sources['saved_array_delivery']=delivery_record
    for name,r in light['source_records'].items():checked(r);sources['saved_array_'+name]=r
    accepted={};reports={};receipts={};light_records={}
    for u in plan['units']:
        name=u['unit']; entry=light['accepted'][name]
        audit=decode(checked(entry['delivery']).read_bytes())
        bindings=decode(checked(entry['bindings']).read_bytes())
        receipt=record(Path(u['output'])/'Completion.json')
        report=decode(Path(receipt['path']).read_bytes())
        require(audit['unit']==name and audit['status']=='PASS_ONE_UNIT_SAVED_ARRAYS_NATIVE_AND_SOURCE_REPLAY' and
                audit['plan_sha256']==PLAN_SHA and audit['producer_completion_sha256']==receipt['sha256'], 'Saved-array receipt identity mismatch')
        require(report['status']=='METHOD_POSTHOC_COMPLETE_PENDING_INDEPENDENT_SCIENTIFIC_REVIEW', 'Posthoc completion missing')
        require(report['config_file']==u['config'] and report['trajectory_completion']==u['completion'] and
                report['posthoc_producer']==plan['producers']['posthoc_v2.py'] and
                report['transfer_native_completion']==plan['transfer_native_completion'], 'Posthoc report provenance mismatch')
        config=decode(checked(u['config']).read_bytes())
        require(report['config']==config and report['identity']['config']==config and
                (config['dataset'],config['arm'],config['seed'])==(u['dataset'],u['arm'],u['seed']), 'Config identity mismatch')
        require(report['identity']['config_sha256']==digest(config) and digest(report['identity'])==u['training_identity_sha256'], 'Training identity digest mismatch')
        require(report['contract']['epochs']==list(range(5)) and report['contract']['interventions']==['uniform','calibration-mean'] and
                report['contract']['protocol_sha256']==plan['protocol_sha256'], 'Posthoc contract drift')
        require(report['training_or_optimizer_updates']==0 and report['labels_used_for_routing'] is False and
                report['model_instances']==1 and report['frozen_final_verification']['status']=='FULL_CONTENT_RECHECK_PASS','Posthoc scope changed')
        items=report['artifacts'];inventory=[(r['kind'],r.get('epoch'),r.get('mode'),r.get('view')) for r in items]
        require(len(inventory)==len(set(inventory)) and set(inventory)==expected_artifacts(u['arm']), 'Artifact inventory incomplete')
        bound={str(Path(r['path']).resolve()):r for r in bindings['bindings']}
        for item in items:
            r=item['file'];p=Path(r['path']).resolve()
            require(p.parent==Path(u['output']).resolve() and bound.get(str(p))==r,'Saved-array binding differs')
            stat=p.stat();stamp=bindings['stamps'][str(p)]
            require(stat.st_size==r['bytes']==stamp['size'] and stat.st_mtime_ns==stamp['mtime_ns'] and stat.st_ino==stamp['inode'], 'Saved-array metadata changed since independent audit')
        accepted[name]=entry;reports[name]=report;receipts[name]=receipt
        light_records[name]=audit['records']
    sources['unit_validation']=accepted;sources['posthoc_receipts']=receipts
    flickr_path=next(Path(k) for k in plan['inputs'] if Path(k).name=='Provenance.json' and Path(k).parent.name=='flickr')
    flickr_record=plan['inputs'][str(flickr_path)]
    flickr=decode(checked(flickr_record).read_bytes())['flickr_provenance'];validate_flickr(flickr)
    sources['flickr_provenance']=flickr_record
    bridge=decode((W/'mechanisms/OrdinaryLoRABridgeDelivery_v1.json').read_bytes())
    sources['bridge_preparation_delivery']=record(W/'mechanisms/OrdinaryLoRABridgeDelivery_v1.json')
    checked(bridge['producer']);checked(bridge['tests']);checked(bridge['ledger'])
    ledger=decode(Path(bridge['ledger']['path']).read_bytes())
    require(Path(bridge['ledger']['path']).with_suffix('.sha256').read_text(encoding='ascii').strip()==bridge['ledger']['sha256'],'Prepared ledger commit SHA differs')
    require(ledger['methods_plan']==plan_record and ledger['status']=='SIX_BASELINES_TWELVE_TRANSFER_CELLS_READY_FULL24_JOIN_PENDING','Prepared bridge identity mismatch')
    require(len(ledger['rows'])==12 and {(r['dataset'],r['seed'],r['view']) for r in ledger['rows']}==
            set(itertools.product(SOURCES,SEEDS,('imagenet','flickr'))),'Bridge baseline rows missing')
    sources['bridge_prepared_ledger']=bridge['ledger']
    return plan,reports,light_records,sources,flickr,bridge


def validate_analysis(analysis,plan,reports,light_records,sources):
    require(analysis['status']==COMPLETE and analysis['gpu_used'] is False,'Committed complete CPU analysis required')
    require(analysis['posthoc_analyzer']==plan['producers']['posthoc_analyze_v2.py'],'Analyzer provenance differs')
    require(analysis['statistics']==next(iter(reports.values()))['contract']['statistics'],'Statistics contract differs')
    expected=list(sources['posthoc_receipts'].values())
    observed=analysis['input_receipts']
    require(len(observed)==24 and sorted(observed,key=lambda x:x['path'])==sorted(expected,key=lambda x:x['path']), 'Analysis completion receipts differ')
    index=validate_rows(analysis['rows'])
    expected_diagnostics=set()
    for u in plan['units']:
        report=reports[u['unit']]
        light={(r['epoch'],r['mode'],r['view'],r['split']):r for r in light_records[u['unit']]}
        for item in report['artifacts']:
            if item['kind']=='calibration_routes': continue
            e,m,v=item['epoch'],item['mode'],item['view']
            if e is not None:
                expected_diagnostics.add(str((ANALYSIS.parent/f"{u['unit']}__epoch{e:03}__{m}__{v}__diagnostics.pt").resolve()))
            for sp in (('calibration','test') if v=='source' else (v,)):
                i,row=index[(u['dataset'],u['arm'],u['seed'],v,sp,e,m)]
                if e is not None: require(row['scores_source']==item['file'], 'Scalar row not bound to saved scores')
                require(analysis['inputs'].get(str(Path(item['file']['path']).resolve()))==item['file'],'Analysis input binding differs')
                saved=light[(e,m,v,sp)];metrics=row['metrics']
                perf={'R1_i2t':saved['accuracy_or_i2t'],'R1_t2i':saved['t2i']} if v=='flickr' else {'classification_accuracy':saved['accuracy_or_i2t']}
                require(all(metrics[k]==value for k,value in perf.items()), 'Independently validated finite readout differs')
                for prefix in (('image_to_text__','text_to_image__') if v=='flickr' else ('',)):
                    defined=metrics[prefix+'tau_defined_queries'];undefined=metrics[prefix+'tau_undefined_queries']
                    require(defined+undefined==saved['rows'],'Tau query counts differ from saved array')
                    require((metrics[prefix+'tau_b'] is None)==(defined==0),'Undefined tau/count mismatch')
                    for k in (3,5,10,20,50,100):
                        if k>saved['candidates']:continue
                        count=metrics[f'{prefix}top{k}_tau_defined_queries']
                        require(0<=count<=saved['rows'] and (metrics[f'{prefix}top{k}_tau_b'] is None)==(count==0), 'Top-k tau/count mismatch')
    observed_diagnostics={str(Path(r['path']).resolve()) for r in analysis['diagnostic_files']}
    require(len(analysis['diagnostic_files'])==432 and observed_diagnostics==expected_diagnostics, 'Full locked diagnostics inventory missing')
    for r in analysis['diagnostic_files']:
        require(Path(r['path']).stat().st_size==r['bytes'] and len(r['sha256'])==64,'Diagnostic file size/identity mismatch')
    return index


def render(summary):
    lines=['# Fixed24 independent scalar review','',BOUNDARIES,'',
           'All values below are fractions except CG and tau. SD is across exactly three seeds, ddof=1. '
           'All metrics and epoch curves are in Summary.json; pointers are JSON pointers into its bound Analysis.json.','']
    lines += ['## Fixed epoch4 and separate native anchors','',
              '| Source | View/split | Arm/mode/state | Metric | Mean | SD | Source rows |',
              '|---|---|---|---|---:|---:|---|']
    for r in summary['aggregates']:
        if r['epoch'] not in (None,4) or r['metric'] not in ('classification_accuracy','R1_i2t','R1_t2i','CG_l2_means_float64'):continue
        st=r['statistics']
        lines.append(f"| {r['dataset']} | {r['view']}/{r['split']} | {r['arm']}/{r['mode']}/{r['epoch']} | {r['metric']} | {fmt(st['mean'])} | {fmt(st['sample_sd_ddof1'])} | {', '.join(r['source_rows'])} |")
    lines += ['', '## All fixed epoch4 contrasts, including negative and mixed results','',
        '| Source | View/split | Left minus right | Metric | Mean delta | Paired SD | + / 0 / - seeds |',
        '|---|---|---|---|---:|---:|---|']
    for r in summary['fixed_epoch4_deltas']:
        if r['metric'] not in ('classification_accuracy','R1_i2t','R1_t2i','CG_l2_means_float64'):continue
        st=r['statistics']
        lines.append(f"| {r['dataset']} | {r['view']}/{r['split']} | {r['left']} minus {r['right']} | {r['metric']} | {fmt(st['mean'])} | {fmt(st['sample_sd_ddof1'])} | {st['positive_seeds']} / {st['zero_seeds']} / {st['negative_seeds']} |")
    lines += ['', '## Editorial recommendations','',
        '- Report the complete fixed matrix and paired seed differences, including negative and mixed transfer findings; do not select an arm, epoch, source or direction after observing performance.',
        '- Treat three seeds as descriptive replication within each fixed source. Do not interpret a descriptive interval, query count, or repeated epoch as population significance or causal evidence.',
        '- Name the posthoc CG estimator explicitly and keep its numbers separate from canonical campaign normalize+fsum CG.',
        '- Replace any Flickr test-only wording with the locked mixed512 split counts. Do not generalize to an official held-out Flickr benchmark.',
        '- Keep ordinary-LoRA comparisons separate from router interventions and geometry; matched recipe is not parameter-identical causal isolation.','']
    return '\n'.join(lines)


def render_diagnostics(summary):
    lines=['# Full fixed24 metric inventory','',BOUNDARIES,'',
           'All metric aggregates use three seeds within source. Source pointers resolve into the bound Analysis.json. '
           'Epoch curves include epoch0..4; native remains separate. Undefined cells are retained.','',
           '| Source | View/split | Arm/mode/epoch | Metric | Mean | SD ddof1 | Source rows |',
           '|---|---|---|---|---:|---:|---|']
    for r in summary['aggregates']:
        st=r['statistics']
        lines.append(f"| {r['dataset']} | {r['view']}/{r['split']} | {r['arm']}/{r['mode']}/{r['epoch']} | {r['metric']} | {fmt(st['mean'])} | {fmt(st['sample_sd_ddof1'])} | {', '.join(r['source_rows'])} |")
    for name in ('fixed_epoch4_deltas','state_deltas'):
        lines += ['', '## '+name,'', '| Source | View/split | Contrast | Metric | Mean delta | Paired SD | + / 0 / - |',
                  '|---|---|---|---|---:|---:|---|']
        for r in summary[name]:
            st=r['statistics'];contrast=(r['left']+' minus '+r['right']) if 'left' in r else r['arm']+' '+r['direction']
            lines.append(f"| {r['dataset']} | {r['view']}/{r['split']} | {contrast} | {r['metric']} | {fmt(st['mean'])} | {fmt(st['sample_sd_ddof1'])} | {st['positive_seeds']} / {st['zero_seeds']} / {st['negative_seeds']} |")
    return '\n'.join(lines)+'\n'


def fmt(x):
    return 'undefined' if x is None else f'{x:.9f}'


def write(path,value):
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--join',action='store_true',help='Run the authorized bridge only after full analysis validation')
    args=parser.parse_args()
    out=HERE/'runs'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out.mkdir(parents=True)
    plan,reports,light,sources,flickr,bridge=authenticate()
    command=bridge['join_command_when_full24_analysis_complete'].replace(
        'fixed24_v3_parent_01/Analysis.json','fixed24_v3_recovery_02/Analysis.json')
    require('fixed24_v3_recovery_02/Analysis.json' in command,'Explicit recovery bridge target missing')
    write(out/'BridgeRecoveryCommand.json',dict(command=command,original_delivery=sources['bridge_preparation_delivery'],
        original_delivery_preserved=True,analysis=str(ANALYSIS),requirement='Run only after complete fixed24 analysis and commit SHA pass'))
    ready=ANALYSIS.is_file() and ANALYSIS.with_suffix('.sha256').is_file()
    delivery=dict(status='PREPARED_TESTED_ANALYSIS_COMMIT_PENDING',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        analysis_target=str(ANALYSIS),boundaries=BOUNDARIES,sources=sources,flickr_provenance=flickr,
        bridge_command=command,required=['Analysis.json and matching Analysis.sha256','complete fixed24 status and exact 672 scalar rows',
            '24 completion receipts, five adapted states, locked views/splits, native anchors and all router interventions'],
        producer=record(__file__),tests=record(HERE/'test_reduce.py'),gpu_used=False)
    if (HERE/'TestEvidence.json').exists():
        delivery['test_evidence']=record(HERE/'TestEvidence.json')
        delivery['test_logs']=[record(HERE/name) for name in ('ReducerTests_GREEN.log','BridgeTests_GREEN.log')]
    if ready:
        analysis,identity=read_committed(ANALYSIS)
        validate_analysis(analysis,plan,reports,light,sources)
        summary=dict(status='FULL_FIXED24_SCALAR_REVIEW_COMPLETE',analysis=identity,boundaries=BOUNDARIES,
                     sources=sources,**reduce_rows(analysis['rows']))
        check_comparisons(summary,analysis['paired_fixed_epoch4'])
        write(out/'Summary.json',summary)
        (out/'ReviewerTables.md').write_text(render(summary),encoding='utf-8')
        (out/'FullMetricTables.md').write_text(render_diagnostics(summary),encoding='utf-8')
        delivery.update(status='FULL_FIXED24_SCALAR_REVIEW_COMPLETE_BRIDGE_PENDING',analysis=identity,
                        summary=record(out/'Summary.json'),tables=record(out/'ReviewerTables.md'),
                        full_metric_tables=record(out/'FullMetricTables.md'))
        if args.join:
            bridge_path=W/'mechanisms/ordinary_lora_bridge_join_v1/Bridge.json'
            require(not bridge_path.parent.exists(),'Bridge output already exists; inspect before reuse, never overwrite')
            with (out/'Bridge.stdout.log').open('wb') as stdout,(out/'Bridge.stderr.log').open('wb') as stderr:
                result=subprocess.run(command,stdout=stdout,stderr=stderr,check=False)
            require(result.returncode==0,'Authorized bridge join failed; see logs and preserved Failure.json')
            joined,bridge_identity=read_committed(bridge_path)
            require(joined['analysis']==identity and len(joined['rows'])==72 and
                    len(joined['descriptive_paired_seed_summaries'])==24,'Bridge join matrix or source identity differs')
            independent_bridge=reduce_bridge(joined['rows'])
            # Cross-check every bridge method value and source pointer against the already read analysis.
            row_index={rowkey(r):r for r in analysis['rows']}
            ledger=decode(Path(bridge['ledger']['path']).read_bytes())
            ordinary={(r['dataset'],r['seed'],r['view']):r for r in ledger['rows']}
            for r in joined['rows']:
                method=row_index[(r['dataset'],r['arm'],r['seed'],r['view'],r['view'],4,'learned')]
                baseline=ordinary[(r['dataset'],r['seed'],r['view'])]
                require(r['method_value']==method['metrics'][r['metric']] and r['method_scores']==method['scores_source'] and
                        r['ordinary_lora_value']==baseline['metrics'][r['metric']] and r['ordinary_scores']==baseline['scores_source'], 'Independent bridge/source join mismatch')
            old={(r['dataset'],r['arm'],r['view'],r['metric']):r for r in joined['descriptive_paired_seed_summaries']}
            for r in independent_bridge:
                previous=old[(r['dataset'],r['arm'],r['view'],r['metric'])];current=r['difference']
                require(math.isclose(previous['mean_difference'],current['mean'],rel_tol=1e-13,abs_tol=2e-15) and
                        previous['seed_differences']==current['seed_values'] and
                        all(previous[k]==current[k] for k in ('positive_seeds','zero_seeds','negative_seeds')),'Independent bridge summary differs')
            write(out/'BridgeSummary.json',dict(status='INDEPENDENT_BRIDGE_SCALAR_REVIEW_COMPLETE',bridge=bridge_identity,
                  analysis=identity,boundaries=BOUNDARIES,rows=independent_bridge))
            (out/'BridgeTables.md').write_text(render_bridge(independent_bridge),encoding='utf-8')
            delivery.update(status='FULL_FIXED24_SCALAR_REVIEW_AND_BRIDGE_JOIN_COMPLETE_PENDING_AUTHOR_REVIEW',bridge=bridge_identity,
                            bridge_summary=record(out/'BridgeSummary.json'),bridge_tables=record(out/'BridgeTables.md'))
    write(out/'Delivery.json',delivery)
    pointer=record(out/'Delivery.json')
    (HERE/'LatestDelivery.json').write_text(json.dumps(pointer,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=delivery['status'],delivery=pointer,bridge_command=command)))
    return 0 if ready else 3


if __name__=='__main__': sys.exit(main())
