"""Private, CPU-only exact-cohort ordinary-LoRA transfer bridge.

Prepare twelve epoch4 baseline cells from six archived trajectories. Join only
after the complete fixed24 posthoc analyzer has committed its authenticated
output. No model loading, inference, CG calculation, training or GPU access.
Large pixels and foundation weights are attested by the pinned native gate,
not re-read or independently re-certified by this bounded bridge.
"""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
for _key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '2'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np

HERE = Path(__file__).resolve().parent
W = HERE.parent
C = W.parent/'replacement_campaign_2026_11_22'
SOURCES = ('dtd','cifar100')
SEEDS = (42,43,44)
ARMS = ('router-static','router-input','rope-fixed','rope-learned')
VIEWS = ('imagenet','flickr')
SHAPES = {'imagenet':[5000,1000], 'flickr':[512,512]}
PLAN_SHA = 'dcc1bf3dc99e62f43cfaa569971b472839fb58e5bc71c983dea0985631713591'
LOCK_SHA = '141fdfe9cce9f8042daccba1c816cd8a585cceb9b62ae33f6eacb13055431287'
CORE_SHA = '719a783b14bd101eac7c411352598b818aca9dd063f2e78abb7b7558e26636e9'
METHOD_SHA = '1a9400bbec7bdc71370b3cb0aa5e18f32d0ec87d1fef3d4e86c430c50a48e5ba'


def require(ok, message):
    if not ok: raise ValueError(message)


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def record(path):
    p=Path(path).resolve()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))


def checked(expected, bindings):
    require(set(expected)=={'path','bytes','sha256'},'Invalid file record')
    p=Path(expected['path']).resolve();key=str(p)
    require(p.stat().st_size==expected['bytes'],'Bound file size drift: '+key)
    if key not in bindings:
        require(record(p)==expected,'Bound file content drift: '+key)
        bindings[key]=expected
    else: require(bindings[key]==expected,'Conflicting file bindings: '+key)
    return p


def bind(path, bindings):
    r=record(path);checked(r,bindings);return r


def attested_large(expected):
    """Explicit receipt trust boundary: stat only, never hash/open large inputs."""
    p=Path(expected['path']).resolve()
    require(p.stat().st_size==expected['bytes'],'Attested asset size drift')
    return expected


def output_dir(path):
    p=Path(path).resolve()
    require(p.is_relative_to(HERE) and p!=HERE,'Bridge outputs must stay inside mechanisms')
    require(not p.exists(),'Output already exists; preserve prior evidence')
    p.mkdir(parents=True);return p


def write(path, value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def validate_matrix(units):
    keys=[(u['dataset'],u['arm'],u['seed']) for u in units]
    require(len(keys)==24 and set(keys)=={(d,a,s) for d in SOURCES for a in ARMS for s in SEEDS},
            'All24 unique fixed source/arm/seed units required')


def validate_meta(meta, expected):
    for k in ('row_ids','row_sha256','row_pixel_sha256','candidate_ids','texts','effective_texts','shape','score_kind'):
        require(meta[k]==expected[k],'Exact metadata mismatch: '+k)
    require(meta['texts']==meta['effective_texts'],'Effective prompts changed')
    require(meta['score_kind']=='normalized_cosine_float32_unscaled','Wrong score convention')
    require(meta.get('labels_accessed') is False,'Transfer producer accessed labels')
    n,c=meta['shape']
    require(len(meta['row_ids'])==len(set(meta['row_ids']))==n,'Missing/duplicate image identity')
    require(len(meta['candidate_ids'])==c and meta['candidate_ids']==list(range(c)), 'Candidate order is not canonical')
    require(len(meta['texts'])==c,'Text count mismatch')


def validate_epoch_receipt(receipt, identity, epoch, kind):
    require(receipt.get('status')=='PROSPECTIVE_EPOCH_COMPLETE' and receipt.get('scientific_result') is True,
            'Incomplete or non-scientific source epoch')
    require(receipt.get('identity')==identity and receipt.get('epoch')==epoch and receipt.get('baseline_kind')==kind,
            'Source epoch/identity/baseline kind mismatch')


def exact_arrays(left, right):
    for key in ('scores','image_features','text_features'):
        require(left[key].dtype==right[key].dtype and np.array_equal(left[key],right[key]),
                'Native arrays differ: '+key)


def finite_metrics(scores, labels, view):
    require(view in VIEWS and scores.ndim==2 and scores.dtype==np.float32 and np.isfinite(scores).all(),
            'Expected finite CPU FP32 score matrix')
    y=np.asarray(labels)
    n,c=scores.shape
    require(y.shape==(n,) and np.issubdtype(y.dtype,np.integer) and ((y>=0)&(y<c)).all(),'Invalid labels')
    if view=='imagenet':return {'classification_accuracy':float(np.mean(scores.argmax(1)==y))}
    require(n==c and np.array_equal(y,np.arange(n)),'Paired retrieval must have exact diagonal truth')
    return {'R1_i2t':float(np.mean(scores.argmax(1)==y)), 'R1_t2i':float(np.mean(scores.argmax(0)==y))}


def check_metrics(metrics, view):
    expected={'classification_accuracy'} if view=='imagenet' else {'R1_i2t','R1_t2i'}
    require(set(metrics)==expected and all(isinstance(x,(int,float)) and np.isfinite(x) and 0<=x<=1 for x in metrics.values()),
            'Finite performance metrics only; CG and geometry are excluded')


def load_pt(path):
    import torch
    require(not torch.cuda.is_initialized(),'CPU bridge must not inherit a CUDA context')
    torch.set_num_threads(2)
    return torch.load(path,map_location='cpu',weights_only=True,mmap=True)


def result_arrays(result, mapping):
    require(result['sample_ids']==mapping['row_ids'] and result['class_ids']==mapping['class_ids'],
            'Saved result sample/class identity mismatch')
    arrays={}
    for k in ('scores','image_features','text_features','predictions','labels'):
        t=result[k]
        require(t.device.type=='cpu','CPU tensors required')
        arrays[k]=t.numpy()
    require(np.array_equal(arrays['labels'],mapping['labels']),'Saved true-label mapping changed')
    require(list(arrays['scores'].shape)==mapping['shape'],'Saved score shape changed')
    require(np.array_equal(arrays['predictions'],arrays['scores'].argmax(1)), 'Saved predictions/tie handling drift')
    for k in ('scores','image_features','text_features'):
        require(arrays[k].dtype==np.float32 and np.isfinite(arrays[k]).all(),'Invalid saved FP32 features/scores')
    return arrays


def receipt(root, identity, epoch, kind, bindings):
    rpath=root/'Receipt.json';r=read(rpath)
    bind(rpath,bindings);bind(root/'Receipt.sha256',bindings)
    require((root/'Receipt.sha256').read_text().strip()==sha(rpath),'Receipt SHA sidecar mismatch')
    validate_epoch_receipt(r,identity,epoch,kind)
    names=['imagenet.json','imagenet.npz','flickr.json','flickr.npz']
    if kind=='trained':names.append('checkpoint.pt')
    for name in names:
        require(Path(name).name==name and name in r['files'],'Missing source artifact')
        checked(dict(path=str((root/name).resolve()),**r['files'][name]),bindings)
    return r


def baseline_arrays(path):
    with np.load(path,allow_pickle=False) as d:
        require(set(d.files)=={'scores','image_features','text_features'},'Unexpected source array inventory')
        a={k:d[k] for k in d.files}
    for k,v in a.items():require(v.dtype==np.float32 and np.isfinite(v).all(),'Nonfinite/non-FP32 source array: '+k)
    require(a['image_features'].shape==(a['scores'].shape[0],512) and
            a['text_features'].shape==(a['scores'].shape[1],512),'Source feature shape mismatch')
    return a


def validate_config(config, unit, foundation, protocol):
    require(all(config[k]==unit[k] for k in ('dataset','arm','seed')),'Method unit configuration mismatch')
    expected={'epochs':4,'batch_size':32,'rank':protocol['lora_rank'],'scale':protocol['lora_alpha_over_rank'],
              'learning_rate':protocol['learning_rate_by_mode']['lora_both'],'schedule':protocol['schedule'],
              'precision':protocol['precision'],'tf32':protocol['tf32'],'score':protocol['training_score']}
    require(all(config.get(k)==v for k,v in expected.items()),'Shared training recipe mismatch')
    require(config['optimizer']==dict(name=protocol['optimizer'],weight_decay=protocol['weight_decay'],
            betas=protocol['betas'],eps=protocol['epsilon']),'Shared optimizer recipe mismatch')
    require(config['model_assets']==foundation['model_assets'] and
            config['reference_cache_keys']['native_model']==foundation['native_model_key'],'Foundation identity mismatch')
    require(config['source_protocol_sha256']==METHOD_SHA,'Method protocol mismatch')


def foundation_and_gate(plan_path, bindings):
    require(sha(plan_path)==PLAN_SHA,'Frozen fixed24 plan drift')
    plan=read(plan_path);bind(plan_path,bindings);validate_matrix(plan['units'])
    for entry in plan['producers'].values():checked(entry,bindings)
    f=read(W/'methods/FoundationAssets.json');bind(W/'methods/FoundationAssets.json',bindings)
    require(f['source_datalock_sha256']==LOCK_SHA and f['source_training_protocol_sha256']==CORE_SHA,'Source foundation binding drift')
    require(sha(f['source_datalock'])==LOCK_SHA and sha(C/'Protocol.json')==CORE_SHA,'Original protocol/data lock drift')
    bind(f['source_datalock'],bindings);bind(C/'Protocol.json',bindings)
    require(sha(W/'Protocol.json')==METHOD_SHA and plan['protocol_sha256']==METHOD_SHA,'Method protocol drift')
    bind(W/'Protocol.json',bindings)
    require(digest(f['model_assets'])==f['native_model_key'],'Foundation key is not asset manifest digest')
    gate=read(checked(plan['transfer_native_completion'],bindings))
    require(gate['status']=='FULL_TRANSFER_NATIVE_GATE_PASS' and gate['batch_size']==32 and
            gate['sampling']=='NONE' and gate['trained_state_loads']==0,'Full native gate required')
    require(gate['frozen_final_verification']['status']=='FULL_CONTENT_RECHECK_PASS' and
            gate['frozen_final_verification']['foundation_assets_sha256']==f['native_model_key'],'Native foundation not certified')
    gp=read(checked(gate['plan'],bindings))
    require(gp['atol']==2e-6 and gp['rtol']==0 and gp['batch_size']==32 and gp['thresholds']==[.01,.02],
            'Native gate tolerance/protocol drift')
    lock=read(f['source_datalock']);protocol=read(C/'Protocol.json')
    mappings={};anchors={};gate_records={}
    for view in VIEWS:
        source=gp['sources'][view];r=read(checked(gate['sources'][view],bindings))
        require(r['plan']==gate['plan'] and r['original_reference_records']==source['reference_records'] and
                r['input']==source['input'],'Native source references drift')
        require(r['status']=='EXACT_DECISIONS_AND_BOUNDED_SCORES_PASS' and r['trained_state_loaded'] is False and
                r['evaluation_batch_size']==32,'Invalid native transfer receipt')
        checks=r['exact_decision_checks']
        require(checks['atol']==2e-6 and checks['rtol']==0 and checks['score_atol2e6_rtol0_pass'] is True and
                0<=checks['score_max_abs']<=2e-6 and checks['winner_mismatches']==checks['tie_mask_row_mismatches']==0 and
                checks['threshold_mismatches']=={'0.01':0,'0.02':0},'Native decision gate not exact')
        require({k:v['sha256'] for k,v in r['model_assets'].items()}==f['model_assets'],'Native model manifest changed')
        for entry in r['model_assets'].values():attested_large(entry)
        attested_large(source['input'])
        prep=read(checked(source['completion'],bindings))
        require(prep['files']['Inputs.pt']==source['input'],'Prepared pixel identity drift')
        for name,entry in prep['files'].items():
            if name!='Inputs.pt':checked(entry,bindings)
        candidate=read(prep['files']['CandidateMapping.json']['path'])
        inventory=read(prep['files']['ImageInventory.json']['path'])
        helper=read(prep['files']['HelperInput.json']['path'])
        require(helper['reference_cache_keys']==source['reference_cache_keys'] and
                helper['evaluation_sha256']==source['input']['sha256'],'Transfer helper/native keys drift')
        rows=lock['transfer'][view]['rows'];texts=lock['transfer'][view]['texts']
        n,c=SHAPES[view]
        require(len(rows)==n and len(texts)==c and source['rows']==n and source['candidates']==c,'Transfer cohort changed')
        meta=dict(row_ids=[x['id'] for x in rows],row_sha256=[x['sha256'] for x in rows],
            row_pixel_sha256=[x['pixel_sha256'] for x in rows],candidate_ids=list(range(c)),texts=texts,
            effective_texts=texts,shape=[n,c],score_kind='normalized_cosine_float32_unscaled',labels_accessed=False)
        validate_meta(meta,meta)
        labels=[x['label'] for x in rows]
        classes=([next(x['id'].split(':')[0] for x in rows if x['label']==i) for i in range(c)]
                 if view=='imagenet' else meta['row_ids'])
        expected_candidates=[dict(index=i,class_id=classes[i],text_utf8_sha256=hashlib.sha256(t.encode()).hexdigest()) for i,t in enumerate(texts)]
        require(candidate['source']==view and candidate['candidates']==expected_candidates and
                candidate['original_candidate_ids']==list(range(c)) and candidate['normalization_or_template_replacement'] is False,
                'Class or prompt/caption identity mismatch')
        require(inventory['source']==view and inventory['every_encoded_sha_verified'] is True and
                inventory['every_decoded_rgb_sha_verified'] is True,'Missing image provenance certification')
        require([{k:x[k] for k in ('sample_id','sha256','pixel_sha256','label')} for x in inventory['images']]==
                [dict(sample_id=x['id'],sha256=x['sha256'],pixel_sha256=x['pixel_sha256'],label=x['label']) for x in rows],
                'Image inventory differs from original lock')
        if view=='flickr':require(texts==[x['caption'] for x in rows] and labels==list(range(n)),'Caption pairing drift')
        mapping=dict(**meta,class_ids=classes,labels=labels,reference_cache_keys=helper['reference_cache_keys'])
        for entry in source['reference_records'].values():checked(entry,bindings)
        validate_meta(read(source['reference_records']['json']['path']),meta)
        native_path=checked(r['files']['NativeScores.pt'],bindings)
        anchors[view]=result_arrays(load_pt(native_path),mapping)
        exact_arrays(baseline_arrays(source['reference_records']['npz']['path']),anchors[view])
        mappings[view]=mapping;gate_records[view]=dict(receipt=gate['sources'][view],native=r['files']['NativeScores.pt'],
            anchor_reference=source['reference_records'],prepared_input=source['input'],prepared_completion=source['completion'])
    configs=[]
    for unit in plan['units']:
        config=read(checked(unit['config'],bindings));validate_config(config,unit,f,protocol)
        provenance_path=Path(config['data_path']).parent/'Provenance.json'
        prep=read(Path(config['data_path']).parent/'Completion.json')
        require(prep['datalock_sha256']==LOCK_SHA and prep['files']['Inputs.pt']==config['data_sha256'], 'Source input lock mismatch')
        bind(Path(config['data_path']).parent/'Completion.json',bindings)
        checked(dict(path=str(provenance_path.resolve()),bytes=provenance_path.stat().st_size,sha256=prep['files']['Provenance.json']),bindings)
        provenance=read(provenance_path)
        require(provenance['source_datalock_sha256']==LOCK_SHA and provenance['source_training_protocol_sha256']==CORE_SHA and
                provenance['model_assets']==f['model_assets'],'Method source provenance changed')
        for split in ('train','calibration','test'):
            ids=[x['id'] for x in lock['datasets'][unit['dataset']]['splits'][split]]
            require(provenance['split_metadata'][split]['row_ids_sha256']==digest(ids),'Source sample ordering differs')
        for view in VIEWS:
            require(all(config['reference_cache_keys'][k]==mappings[view]['reference_cache_keys'][k]
                        for k in ('native_model','preprocessing')),'Source/transfer foundation preprocessing mismatch')
        configs.append(config)
    return plan,f,protocol,mappings,anchors,gate_records


def prepare(plan_path, output):
    started=time.perf_counter();out=output_dir(output);bindings={}
    try:
        plan,f,protocol,mappings,anchors,gates=foundation_and_gate(plan_path,bindings)
        rows=[]
        for dataset in SOURCES:
            for seed in SEEDS:
                unit=f'{dataset}__lora_both__s{seed}';root=C/'scientific_core'/unit
                identity=read(root/'Identity.json');bind(root/'Identity.json',bindings)
                require(identity['unit']==unit and identity['smoke'] is False and identity['datalock_sha256']==LOCK_SHA and
                        identity['protocol_sha256']==CORE_SHA and identity['model_files']==f['model_assets'], 'Ordinary-LoRA source identity mismatch')
                for name,h in identity['producer_sha256'].items():
                    require(Path(name).name==name and sha(C/'runtime'/name)==h,'Original producer source drift')
                    bind(C/'runtime'/name,bindings)
                trained=receipt(root/'epoch_004',identity,4,'trained',bindings)
                native=receipt(root/'frozen_baseline',identity,0,'native_frozen',bindings)
                require(trained['global_step']==252,'Ordinary-LoRA training budget differs')
                for view in VIEWS:
                    m=mappings[view]
                    for folder in ('epoch_004','frozen_baseline'):validate_meta(read(root/folder/(view+'.json')),m)
                    require(native['files'][view+'.npz']['sha256']==gates[view]['anchor_reference']['npz']['sha256'],
                            'Ordinary native archive differs from gate anchor')
                    actual=baseline_arrays(root/'epoch_004'/(view+'.npz'))
                    require(list(actual['scores'].shape)==m['shape'],'Ordinary transfer matrix shape changed')
                    metrics=finite_metrics(actual['scores'],m['labels'],view);check_metrics(metrics,view)
                    rows.append(dict(dataset=dataset,arm='ordinary-lora-both',seed=seed,epoch=4,view=view,
                        split=view,mode='learned',metrics=metrics,checkpoint=record(root/'epoch_004/checkpoint.pt'),
                        receipt=record(root/'epoch_004/Receipt.json'),metadata=record(root/'epoch_004'/(view+'.json')),
                        scores_source=record(root/'epoch_004'/(view+'.npz')),native_archive=record(root/'frozen_baseline'/(view+'.npz'))))
                print(json.dumps(dict(status='ORDINARY_LORA_TRANSFER_AUTHENTICATED',unit=unit)),flush=True)
        result=dict(schema='A1_ORDINARY_LORA_TRANSFER_BRIDGE_LEDGER_V1',
            status='SIX_BASELINES_TWELVE_TRANSFER_CELLS_READY_FULL24_JOIN_PENDING',producer=record(__file__),
            methods_plan=record(plan_path),foundation=record(W/'methods/FoundationAssets.json'),
            native_gate=plan['transfer_native_completion'],mappings=mappings,gate_records=gates,rows=rows,
            source_protocol=record(C/'Protocol.json'),bindings=bindings,
            metric_units='Fractions; differences are method minus ordinary-LoRA. Multiply by100 for percentage points.',
            scope='Fixed epoch4, exact source and paired seed. Transfer only. No CG; no new evaluation or source baseline.',
            comparison_boundary='Matched source/seed/cohort/shared optimizer recipe, not identical parameterization, initialization draws, per-parameter learning rates or causal isolation.',
            large_asset_trust='Pinned parent native gate attests foundation and pixel content. This CPU bridge checked manifest identity and size, not large asset content afresh.',
            gpu_used=False,models_loaded=False,elapsed_seconds=time.perf_counter()-started)
        write(out/'Ledger.json',result);(out/'Ledger.sha256').write_text(sha(out/'Ledger.json')+'\n',encoding='ascii')
        return result
    except Exception as e:
        write(out/'Failure.json',dict(status='FAILED_CLOSED_PRESERVED',error=repr(e)));raise


def paired_summary(rows):
    groups={}
    for r in rows:
        key=tuple(r[k] for k in ('dataset','arm','view','metric'))
        bucket=groups.setdefault(key,{})
        require(r['seed'] not in bucket,'Duplicate paired seed')
        bucket[r['seed']]=r['difference']
    summaries=[]
    for key,values in sorted(groups.items()):
        require(set(values)==set(SEEDS),'Three paired seeds required; no dropping')
        require(all(np.isfinite(x) for x in values.values()),'Nonfinite paired difference')
        summaries.append(dict(zip(('dataset','arm','view','metric'),key),
            mean_difference=float(np.mean([values[s] for s in SEEDS])),seed_differences=values,
            positive_seeds=sum(x>0 for x in values.values()),negative_seeds=sum(x<0 for x in values.values()),
            zero_seeds=sum(x==0 for x in values.values()),statistical_unit='paired seed within fixed source',
            interpretation='Descriptive three-seed finite comparison; no pooled datasets/checkpoints or significance claim'))
    return summaries


def expected_artifacts(arm):
    entries={('native',None,'native',v) for v in ('source',*VIEWS)}
    entries.update(('adapted',e,'learned',v) for e in range(5) for v in ('source',*VIEWS))
    if arm.startswith('router'):
        entries.update(('adapted',4,m,v) for m in ('uniform','calibration-mean') for v in ('source',*VIEWS))
        entries.add(('calibration_routes',None,None,None))
    return entries


def join(ledger_path, analysis_path, output):
    started=time.perf_counter();out=output_dir(output);bindings={}
    try:
        require(Path(ledger_path).with_suffix('.sha256').read_text().strip()==sha(ledger_path),'Ledger SHA mismatch')
        ledger=read(ledger_path);bind(ledger_path,bindings)
        require(ledger['schema']=='A1_ORDINARY_LORA_TRANSFER_BRIDGE_LEDGER_V1' and
                ledger['status']=='SIX_BASELINES_TWELVE_TRANSFER_CELLS_READY_FULL24_JOIN_PENDING','Prepared bridge ledger required')
        checked(ledger['producer'],bindings)
        for entry in ledger['bindings'].values():checked(entry,bindings)
        plan=read(checked(ledger['methods_plan'],bindings));validate_matrix(plan['units'])
        require(sha(ledger['methods_plan']['path'])==PLAN_SHA,'Method plan changed')
        analysis=read(analysis_path);bind(analysis_path,bindings)
        require(Path(analysis_path).with_suffix('.sha256').read_text().strip()==sha(analysis_path),'Posthoc analysis SHA mismatch')
        require(analysis['status']=='FULL24_CPU_POSTHOC_ANALYSIS_COMPLETE_PENDING_SCIENTIFIC_REVIEW' and analysis['gpu_used'] is False,
                'Complete fixed24 CPU analyzer required; partial comparisons prohibited')
        require(analysis['posthoc_analyzer']==plan['producers']['posthoc_analyze_v2.py'],'Analysis producer differs from frozen plan')
        checked(analysis['posthoc_analyzer'],bindings)
        expected_receipts={str((Path(u['output'])/'Completion.json').resolve()) for u in plan['units']}
        observed=[str(Path(x['path']).resolve()) for x in analysis['input_receipts']]
        require(len(observed)==24 and set(observed)==expected_receipts,'Analysis is not the exact complete24 plan')
        anchors={v:result_arrays(load_pt(checked(ledger['gate_records'][v]['native'],bindings)),ledger['mappings'][v]) for v in VIEWS}
        baseline={(r['dataset'],r['seed'],r['view']):r for r in ledger['rows']}
        require(len(baseline)==12,'All twelve unique baseline transfer cells required')
        joined=[]
        for unit in plan['units']:
            cpath=Path(unit['output'])/'Completion.json'
            expected=next(x for x in analysis['input_receipts'] if str(Path(x['path']).resolve())==str(cpath.resolve()))
            report=read(checked(expected,bindings));config=read(checked(unit['config'],bindings))
            require(report['status']=='METHOD_POSTHOC_COMPLETE_PENDING_INDEPENDENT_SCIENTIFIC_REVIEW' and
                report['config']==config and report['config_file']==unit['config'],'Posthoc configuration or completion drift')
            require(report['identity']['config']==config and report['identity']['config_sha256']==digest(config), 'Method identity/config mismatch')
            require(report['training_or_optimizer_updates']==0 and report['labels_used_for_routing'] is False and
                    report['model_instances']==1,'Unexpected posthoc training or label routing')
            require(report['transfer_native_completion']==ledger['native_gate'] and report['posthoc_producer']==plan['producers']['posthoc_v2.py'],
                    'Posthoc native gate/producer mismatch')
            require(report['trajectory_completion']==unit['completion'],'Wrong source trajectory completion')
            checked(unit['completion'],bindings)
            identity_path=Path(unit['trajectory'])/'Identity.json'
            checked(dict(path=str(identity_path.resolve()),bytes=identity_path.stat().st_size,
                         sha256=unit['source_manifest_files']['Identity.json']),bindings)
            require(read(identity_path)==report['identity'] and digest(report['identity'])==unit['training_identity_sha256'], 'Training identity mismatch')
            require(report['contract']['protocol_sha256']==METHOD_SHA and report['contract']['original_diagnostic_protocol_sha256']==CORE_SHA,
                    'Posthoc protocol mismatch')
            artifacts=report['artifacts'];keys=[(x['kind'],x.get('epoch'),x.get('mode'),x.get('view')) for x in artifacts]
            require(len(keys)==len(set(keys)) and set(keys)==expected_artifacts(unit['arm']),'Incomplete posthoc states/interventions')
            for view in VIEWS:
                mapping=ledger['mappings'][view]
                prep_input=ledger['gate_records'][view]['prepared_input']
                require(report['inputs'].get(str(Path(prep_input['path']).resolve()))==prep_input,'Method transfer pixels differ from admitted input')
                native_item=next(x for x in artifacts if x['kind']=='native' and x['view']==view)
                actual_item=next(x for x in artifacts if x['kind']=='adapted' and x['view']==view and x['epoch']==4 and x['mode']=='learned')
                for item in (native_item,actual_item):require(Path(item['file']['path']).resolve().parent==Path(unit['output']).resolve(),'Artifact path escapes fixed run')
                native=result_arrays(load_pt(checked(native_item['file'],bindings))[view],mapping)
                exact_arrays(native,anchors[view])
                payload=load_pt(checked(actual_item['file'],bindings))
                require(payload['epoch']==4 and payload['mode']=='learned' and set(payload['results'])=={view} and
                        payload['task']==('classification' if view=='imagenet' else 'paired_retrieval'),'Wrong epoch/task/mode in saved transfer')
                actual=result_arrays(payload['results'][view],mapping)
                performance=finite_metrics(actual['scores'],mapping['labels'],view);check_metrics(performance,view)
                matched=[r for r in analysis['rows'] if all(r[k]==unit[k] for k in ('dataset','arm','seed')) and
                         r['view']==r['split']==view and r['epoch']==4 and r['mode']=='learned']
                require(len(matched)==1 and matched[0]['scores_source']==actual_item['file'],'Missing/ambiguous epoch4 analysis row')
                require(all(matched[0]['metrics'][k]==v for k,v in performance.items()),'Finite performance summary drift')
                b=baseline[(unit['dataset'],unit['seed'],view)];check_metrics(b['metrics'],view)
                for metric,value in performance.items():
                    joined.append(dict(dataset=unit['dataset'],arm=unit['arm'],seed=unit['seed'],view=view,epoch=4,
                        mode='learned',metric=metric,method_value=value,ordinary_lora_value=b['metrics'][metric],
                        difference=value-b['metrics'][metric],difference_direction='method_minus_ordinary_lora',
                        method_scores=actual_item['file'],ordinary_scores=b['scores_source'],native_gate=ledger['native_gate']))
        require(len(joined)==72,'Expected72 finite metric contrasts from48 transfer cells')
        result=dict(schema='A1_ORDINARY_LORA_MATCHED_TRANSFER_JOIN_V1',status='CPU_MATCHED_TRANSFER_JOIN_COMPLETE_PENDING_INDEPENDENT_SCIENTIFIC_GO',
            rows=joined,descriptive_paired_seed_summaries=paired_summary(joined),ledger=record(ledger_path),
            analysis=record(analysis_path),producer=record(__file__),bindings=bindings,
            comparison_boundary=ledger['comparison_boundary'],metric_units=ledger['metric_units'],
            geometry_policy='No CG or geometry measurement is imported, compared, recomputed or pooled.',
            scientific_acceptance='CPU provenance/finite-readout acceptance only; not independent scientific GO.',
            gpu_used=False,models_loaded=False,elapsed_seconds=time.perf_counter()-started)
        write(out/'Bridge.json',result);(out/'Bridge.sha256').write_text(sha(out/'Bridge.json')+'\n',encoding='ascii')
        return result
    except Exception as e:
        write(out/'Failure.json',dict(status='FAILED_CLOSED_PRESERVED',error=repr(e)));raise


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare');p.add_argument('--plan',type=Path,default=W/'methods/PosthocMatrix_E_v3.json');p.add_argument('--output',type=Path,required=True)
    p=sub.add_parser('join');p.add_argument('--ledger',type=Path,required=True);p.add_argument('--analysis',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=prepare(args.plan,args.output) if args.command=='prepare' else join(args.ledger,args.analysis,args.output)
    print(json.dumps(dict(status=result['status'],rows=len(result['rows']),gpu_used=False)),flush=True)


if __name__=='__main__':main()
