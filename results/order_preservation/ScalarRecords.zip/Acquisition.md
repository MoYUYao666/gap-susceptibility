# Exact portable_v3 acquisition and authentication boundary

The byte-identical `dependencies/PortableAcquisition_v3.zip` contains the standalone
validator, CPU tests, RuntimeRequirements, README and exact acquisition manifest.
Replay extracts it to its output's `acquisition/` directory. Supply this manifest
fingerprint from a trusted separate record, rather than trusting a modified manifest:

```text
65c5676006966205a058f43e46e05e52ab9b2c112af2bd218c72056b3e74ec92
```

No automatic downloader or terms acceptance is included. Obtain matching assets
independently and lawfully. Every repository member has a pinned revision-specific
locator, byte count and SHA256 in the manifest; these are exact locators, not a
claim of live network accessibility. Do not use a moving branch or substitute a
different mirror. See the nested README and manifest for full source-specific lists.

| Source | Pinned repository / revision | Required root |
|---|---|---|
| CIFAR100 | `uoft-cs/cifar100`, `aadb3af77e9048adbea6b47c21a81e47dd092ae5` | Directory containing the two named parquet basenames (`cifar100` subdirectory) |
| ImageNet mirror | `mrm8488/ImageNet1K-val`, `f004a913f9170e5ff39e63f6172ee3aee918197c9` | Repository root with `data/`, `README.md`, `dataset_infos.json` |
| Food101 | `ethz/food101`, `83488de741c1bd1ce27aa6a2b33e19c7bdf92ca9` | Named source-lock layout; not promoted to newly authenticated cache-chain evidence |
| DTD | Original DTD members, split1 lists and SHA/size in manifest | DTD root containing `images/` and `labels/` |
| Flickr512 | Exact image basenames, sentence IDs, caption UTF-8/image/pixel fingerprints and candidate order in manifest | Lawfully obtained images plus separately supplied matching author annotation ZIP |

Retain physical parquet row order (zero-based `source_row`), ordered cohort position,
role and original label. Do not presort or re-sample. Decode embedded image bytes
using Pillow RGB conversion **without EXIF transpose**. Pixel hash is SHA256 of
ASCII `RGB:width:height:` plus row-major RGB bytes. Class order and exact prompt
punctuation/UTF-8 hashes are specified; CIFAR mirror `cra` class26 maps to `crab`
and underscores map to spaces as recorded, not guessed. ImageNet mirror WNID order
is not authenticated as an official original-filename crosswalk. No weights are
needed to verify identities; no raw captions or token buffers are distributed.

## Flickr annotation update, without changing old packages

The later local provenance authenticates this **named annotation snapshot**:

```text
Locator: https://cs.stanford.edu/people/karpathy/deepimagesent/caption_datasets.zip
ZIP SHA256: 4cfd70132527b80933105e5829dc9034eaab9573482e2e680abbab6130244817
Member: dataset_flickr30k.json
Member SHA256: db779ee2c5df40c25ff0eebeca464f6124b620cc4a9398650aea71fd1b53d4af
```

Select the exact `sentid` and candidate identity in the manifest and verify its
caption UTF-8 hash. This cohort has **473 train / 20 validation / 19 test** in the
named Karpathy snapshot; it is **not test-only**, not the official dataset-creator
split and not a newly held-out retrieval benchmark. No test-only performance claim
or inference from the name Flickr30k is permitted. This narrowly supersedes the
older editorial v4 README's lack of authenticated annotation/split identification;
the original v4 bytes and its historical status are preserved unchanged.

Authentication of that ZIP/member does **not** establish original upstream image
content identity, TFDS checksum verification, caption publication permission or
image/annotation redistribution rights. These remain unestablished. Dataset-creator
registry locator: https://shannon.cs.illinois.edu/DenotationGraph/data/index.html
Current scoped metadata appears in `inputs/acquisition/FlickrAuthentication.json`.

## Offline commands (no acquisition is performed by this attachment)

From the extracted `acquisition/` directory:

```powershell
$fp='65c5676006966205a058f43e46e05e52ab9b2c112af2bd218c72056b3e74ec92'
python -B -I validate_inputs_v3.py --manifest-sha256 $fp
python -B -I validate_inputs_v3.py --manifest-sha256 $fp --dataset dtd --asset-root '<matching-dtd-root>'
python -B -I validate_inputs_v3.py --manifest-sha256 $fp --dataset cifar100 --asset-root '<matching-cifar100-directory>'
python -B -I validate_inputs_v3.py --manifest-sha256 $fp --dataset food101 --asset-root '<matching-food101-root>'
python -B -I validate_inputs_v3.py --manifest-sha256 $fp --dataset imagenet --asset-root '<matching-imagenet-mirror-root>'
python -B -I validate_inputs_v3.py --manifest-sha256 $fp --dataset flickr --asset-root '<lawful-flickr-image-directory>' --annotation-zip '<matching-caption_datasets.zip>'
python -B -I -m unittest discover -s . -p test_portable_v3.py -v
```

Manifest structure needs only the standard library. Actual image checks additionally
need Pillow; parquet checks need PyArrow. Observed original validator environment
was Python3.14.6, Pillow12.3.0, PyArrow23.0.1; consult RuntimeRequirements rather than
silently changing an environment. A structure-only PASS is not acquired-input PASS.
No full source input scan is repeated in this additive statistical-tier task.
