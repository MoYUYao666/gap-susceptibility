"""Portable recipe and safe-archive tests. No scientific execution."""
import copy
import json
import stat
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

import portable

ROOT = Path(__file__).resolve().parent


class RecipeTests(unittest.TestCase):
    def setUp(self):
        self.common = portable.read(ROOT / "inputs/Common.json")
        self.sources = portable.read(ROOT / "SourceHashes.json")["original_sources"]
        self.item = portable.read(next((ROOT / "inputs/spectral").glob("*.json")))

    def test_all24_reconstructed_not_just_hashed(self):
        self.assertEqual(portable.replay(ROOT)["units"], 24)

    def test_all24_json_compatible_yaml(self):
        for unit in portable.units():
            self.assertEqual(portable.read(ROOT / "recipes" / (unit + ".json")),
                             portable.read(ROOT / "recipes" / (unit + ".yaml")))

    def test_unknown_value_cannot_be_guessed(self):
        self.common["not_established"][next(iter(self.common["not_established"]))] = 0
        with self.assertRaisesRegex(ValueError, "null"):
            portable.reconstruct(self.item, self.common, self.sources)

    def test_wrong_gate_preset_rejected(self):
        self.item["reference_projection"]["configuration"]["layers"] = [2, 3, 4]
        with self.assertRaisesRegex(ValueError, "Gate configuration"):
            portable.reconstruct(self.item, self.common, self.sources)

    def test_wrong_learning_rate_rejected(self):
        self.common["protocol"]["learning_rate_by_mode"]["lora_both"] = .1
        with self.assertRaisesRegex(ValueError, "optimizer"):
            portable.reconstruct(self.item, self.common, self.sources)

    def test_reference_count_rejected(self):
        self.item["reference_projection"]["calibration_counts"][next(iter(self.item["reference_projection"]["calibration_counts"]))] = 0
        with self.assertRaisesRegex(ValueError, "presentation count"):
            portable.reconstruct(self.item, self.common, self.sources)

    def test_state_validation_tier_not_direct(self):
        result = portable.reconstruct(self.item, self.common, self.sources)
        self.assertEqual(result["archived_state_validation"]["category"], portable.INHERITED)
        self.assertFalse(result["archived_state_validation"]["origin"]["fresh_checkpoint_decode"])

    def test_acceptance_hash_tamper_rejected(self):
        self.item["archived_acceptance"]["reference_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "linkage"):
            portable.reconstruct(self.item, self.common, self.sources)

    def test_unsafe_member_names(self):
        for name in ("../escape", "/absolute", "Z:/absolute", "a\\b", "a/./b", "a//b"):
            with self.assertRaises(ValueError):
                portable.safe_name(name)

    def test_safe_member_name(self):
        self.assertEqual(str(portable.safe_name("inputs/spectral/u.json")), "inputs/spectral/u.json")

    def make_zip(self, directory, mode):
        path = directory / "test.zip"
        data = b"safe scalar"
        with zipfile.ZipFile(path, "w") as archive:
            if mode == "traversal":
                archive.writestr("../escape", data)
            elif mode == "duplicate":
                archive.writestr("A.json", data)
                archive.writestr("a.json", data)
            elif mode == "symlink":
                info = zipfile.ZipInfo("link")
                info.create_system = 3
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                archive.writestr(info, b"outside")
            else:
                archive.writestr("scalar.txt", data)
            expected = portable.record(data)
            if mode == "sha":
                expected["sha256"] = "0" * 64
            archive.writestr("MANIFEST.json", json.dumps({"members": {"scalar.txt": expected}}))
        return path

    def test_zip_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "Unsafe"):
                portable.validated_zip(self.make_zip(Path(tmp), "traversal"))

    def test_zip_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "Duplicate"):
                portable.validated_zip(self.make_zip(Path(tmp), "duplicate"))

    def test_zip_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "Disallowed"):
                portable.validated_zip(self.make_zip(Path(tmp), "symlink"))

    def test_zip_sha_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, "SHA/size"):
                portable.validated_zip(self.make_zip(Path(tmp), "sha"))

    def test_safe_extract_and_existing_destination_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            path = self.make_zip(tmp, "valid")
            self.assertEqual(portable.extract(path, tmp / "out")["extracted_member_sha"], "PASS")
            with self.assertRaisesRegex(ValueError, "must be new"):
                portable.extract(path, tmp / "out")

    def test_no_scientific_libraries(self):
        self.assertFalse({"torch", "numpy", "transformers"}.intersection(sys.modules))


if __name__ == "__main__":
    unittest.main(verbosity=2)
