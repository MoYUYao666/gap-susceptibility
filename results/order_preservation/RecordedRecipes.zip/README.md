# Recorded Spectral Recipes v1

An additive portable configuration companion: **24 JSON-compatible YAML + JSON
pairs**, 24 sanitized source projections, common recorded settings, source hashes,
and standard-library reconstruction/verification code. JSON syntax is the YAML 1.2
subset used here; no YAML library or scientific dependency is required.

## What this establishes

The matrix is DTD/CIFAR-100 x early/late x frozen_reference/dynamic x seeds 42/43/44.
These are 24 trajectories, not 144 independent experiments. The original spectral
Inputs snapshots recorded protocols and DataLock but no separate
`effective_configuration` container. **An absent container is not 24 absent full
protocols.** This attachment supplies a labeled reconstruction, not a fabricated
contemporaneous dump and not a replacement for an earlier package.

Each recipe distinguishes:

1. `DIRECT_RECORDED`: the actual protocol settings, identity/runtime subset,
   `References.json#/payload/configuration`, calibration counts and native-frozen
   per-head calibration reference means, and safely selected model/preprocessor/
   tokenizer configured JSON fields. No resolved defaults are silently added.
2. `EXACT_FROM_BOUND_PRODUCER_AND_RECORDED_INPUTS`: explicit optimizer calls,
   schedule, LoRA placement/rank/scaling, batching, step counts, numerical/backend
   policy, and accepted-launch flags. Original producer hashes and line bindings
   are in `inputs/BoundCodeFacts.json` and `SourceHashes.json`.
3. `INHERITED_ARCHIVED_VALIDATION_NOT_FRESH_STATE_INSPECTION`: four false AdamW
   flags supported by the archived 24-run/144-state record validator. That
   validator was not rerun. Its decoupled-weight-decay rule permits an absent key;
   historical key presence is therefore not invented.
4. `NOT_ESTABLISHED_IN_BOUNDED_ARCHIVE_REVIEW`: ten explicitly named unresolved
   field groups remain null, with reasons. These include omitted third-party
   defaults, complete resolved preprocessing/tokenizer objects, exact inherited
   environment variables, library-build/driver details, and exhaustive attempt
   history. Versions and accepted commands do not establish a full historical
   process-environment dump.

The explicit program-call recipe is reproducible from the included sanitized
settings with the portable entrypoint below. It is **not a training launcher**,
not a full historical library-resolved configuration capture, and not evidence
that a training trajectory can be publicly replayed from this small attachment.
Reconstruction recomputes each recipe's settings and validates source/cell/count
relationships, rather than merely comparing stored digests.

## Portable CPU commands

From an extracted new directory using Python 3.10 or later:

```text
python -B -X utf8 portable.py replay --root .
python -B -X utf8 portable.py replay --root . --output ../new_recipe_replay
python -B -X utf8 -m unittest discover -s . -p test_portable.py -v
python -B -X utf8 portable.py check-zip ../RecordedSpectralRecipes_v1.zip
python -B -X utf8 portable.py extract ../RecordedSpectralRecipes_v1.zip ../new_isolated_extraction
```

Output/extraction directories must not exist. Neither the replay nor tests import
torch, numpy, transformers, run a producer, contact a network, or access a GPU.
Original producer paths and accepted training commands are not executable assets
in this attachment. Setting empty CUDA visibility is an additional local guard.

## Source and integrity semantics

`SourceHashes.json` uses sanitized logical source IDs, not private machine paths.
Each hash labeled `original_sources` describes **the original full source file**,
not the smaller projection included here. `MANIFEST.json` separately binds every
included member except itself by exact size/SHA; the external archive receipt
binds the ZIP and manifest. CRC, traversal, duplicate/case-collision, symlink,
size, exact member inventory and member SHA checks precede isolated extraction.

`inputs/Common.json` omits redundant full cell lists; the exact 24-cell matrix is
implemented and checked by `portable.units()`. Protocol analysis-only/other-mode
keys are retained as recorded declarations, not mislabeled as consumed spectral
training arguments. Raw configured JSON is not a complete resolved library object.
The loss is represented by its exact call, not guessed omitted keyword defaults.

## Scientific, privacy and access scope

Early/late specify gate layers 0/1/2 or 9/10/11. Both use ordinary rank-8 LoRA in
all 12 layers of both towers. This is an explicit CLIP adaptation, not faithful
DSW reproduction, not effective-capacity isolation, and not layer-causal evidence.
Four training epochs, source training/calibration/test and locked transfer views
remain distinct. Flickr512 is mixed split (473 train / 20 validation / 19 test),
not a test-only retrieval benchmark. It is not redefined or reacquired here.

No raw images/captions/prompts/token IDs/masks, foundation or adapted weights,
optimizer/RNG tensors, feature/score arrays, diagnostic arrays, manuscripts,
credentials, or absolute local paths are included. Reference means are small
native-frozen calibration aggregates, **not learned gate/LoRA weights**.
Optimizer hyperparameter scalars are configuration, not an optimizer checkpoint.
No new scientific metrics or CG calculations were run; posthoc double-means and
campaign canonical normalization-plus-fsum remain separate and must not be pooled.

This local shareable attachment does not grant redistribution rights to excluded
datasets, tokenizers, derived features/scores, foundation models or state files.
Those assets retain separate local/access-policy tiers and indices. No public
snapshots, authentication bypass or full public end-to-end reproducibility is
claimed. No archive, global navigation, manuscript, DOI, tag or release is changed.
