"""Portable recorded-spectral recipe reconstruction. Standard library only.

This reconstructs JSON-compatible YAML documents, never training or inference.
"""
import argparse
import hashlib
import itertools
import json
import math
import re
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

DIRECT = "DIRECT_RECORDED"
DERIVED = "EXACT_FROM_BOUND_PRODUCER_AND_RECORDED_INPUTS"
INHERITED = "INHERITED_ARCHIVED_VALIDATION_NOT_FRESH_STATE_INSPECTION"
UNKNOWN = "NOT_ESTABLISHED_IN_BOUNDED_ARCHIVE_REVIEW"


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def record(data):
    if isinstance(data, Path):
        data = data.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    require(path.stat().st_size < 4 * 1024 * 1024, "Oversized metadata member")
    return json.loads(path.read_text(encoding="utf-8"))


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False)
        handle.write("\n")


def units():
    return {f"{d}__{p}__{m}__s{s}" for d, p, m, s in itertools.product(
        ("dtd", "cifar100"), ("early", "late"), ("frozen_reference", "dynamic"), (42, 43, 44))}


def group(category, values, origin):
    return {"category": category, "values": values, "origin": origin}


def explicit_recipe(item, common):
    p = common["protocol"]
    ext = common["extension_protocol"]
    cell = item["recorded"]["cell"]
    ntrain = item["count_projection"]["train_rows"]
    count = item["count_projection"]["trainable_count"]
    require(p["batch_size"] == 32 and p["epochs"] == 4 and ntrain == 2000 and count == 737346,
            "Fixed training/count contract changed")
    require(p["learning_rate_by_mode"]["lora_both"] == ext["learning_rate"] == .0005
            and p["weight_decay"] == ext["weight_decay"] == .01
            and p["betas"] == ext["betas"] == [.9, .999] and p["epsilon"] == ext["epsilon"] == 1e-8,
            "Core/extension optimizer recipe mismatch")
    require(p["lora_rank"] == ext["lora_rank"] == 8
            and p["lora_alpha_over_rank"] == 2
            and p["lora_targets"] == ext["lora_targets"] == ["q_proj", "k_proj", "v_proj"],
            "LoRA recipe mismatch")
    require(common["bound_code_facts"]["foreach"] is False
            and common["bound_code_facts"]["fused"] is False
            and common["bound_code_facts"]["layer_count_each_tower"] == 12,
            "Explicit bound implementation facts changed")
    require(cell["seed"] in (42, 43, 44) and cell["gate_mode"] in ext["gate_modes"], "Invalid cell")
    return {
        "optimizer": {"name": "AdamW", "lr": p["learning_rate_by_mode"]["lora_both"],
                      "weight_decay": p["weight_decay"], "betas": p["betas"], "eps": p["epsilon"],
                      "foreach": common["bound_code_facts"]["foreach"], "fused": common["bound_code_facts"]["fused"]},
        "schedule": {"name": "LambdaLR", "multiplier": 1.0, "step_after_each_optimizer_update": True},
        "model": {"mode": "lora_both", "dtype": "float32", "attention_implementation": "eager",
                  "lora_layers_each_tower": list(range(common["bound_code_facts"]["layer_count_each_tower"])),
                  "lora_rank": p["lora_rank"], "lora_targets": p["lora_targets"],
                  "lora_alpha_over_rank": p["lora_alpha_over_rank"], "lora_dropout": 0,
                  "lora_A_initialization": "kaiming_uniform_(a=sqrt(5))", "lora_B_initialization": "zeros",
                  "trainable_count": count},
        "training": {"epochs": p["epochs"], "batch_size": p["batch_size"], "train_rows": ntrain,
                     "steps_per_epoch": math.ceil(ntrain / p["batch_size"]), "last_batch_rows": ntrain % p["batch_size"],
                     "drop_last": False, "updates_per_run": math.ceil(ntrain / p["batch_size"]) * p["epochs"],
                     "accumulation_batches": 1, "gradient_clipping": None, "amp": False,
                     "loss_call": "F.cross_entropy(scores.float(),labels)",
                     "epoch_order": "torch.randperm(ntrain,generator=torch.Generator(device='cpu').manual_seed(seed+epoch*1000003))"},
        "evaluation": {"batch_size": p["batch_size"], "score_kind": "normalized_cosine_float32_unscaled",
                       "labels_accessed": False, "use_logit_scale": False},
        "backend": {"matmul_allow_tf32": False, "cudnn_allow_tf32": False, "cudnn_benchmark": False,
                    "cudnn_deterministic": True, "deterministic_algorithms": True},
        "tokens": {"padding": True, "truncation": False,
                   "model_max_length": common["model_configured"]["tokenizer_config.json"]["model_max_length"]}}


def reconstruct(item, common, sources):
    require(item["unit"] in units(), "Unexpected run")
    cell = item["recorded"]["cell"]
    require(item["unit"] == f"{cell['dataset']}__{cell['preset']}__{cell['gate_mode']}__s{cell['seed']}",
            "Cell/unit mismatch")
    require(item["recorded"]["smoke"] is False and item["recorded"]["technical"] is False, "Technical run prohibited")
    configuration = item["reference_projection"]["configuration"]
    require(configuration["layers"] == common["extension_protocol"]["presets"][cell["preset"]]
            and configuration["mode"] == cell["gate_mode"]
            and configuration["preset"] == cell["preset"], "Gate configuration mismatch")
    keys = {f"{t}_{l}" for t in ("text", "vision") for l in configuration["layers"]}
    refs = item["reference_projection"]["references"]
    counts = item["reference_projection"]["calibration_counts"]
    require(set(configuration["gates"]) == set(refs) == set(counts) == keys, "Gate key inventory mismatch")
    for key in keys:
        require(len(refs[key]) == configuration["gates"][key]["heads"]
                and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in refs[key]),
                "Invalid aggregate reference means")
        expected = item["count_projection"]["source_classes" if key.startswith("text_") else "calibration_rows"]
        require(counts[key] == expected, "Reference presentation count changed")
    require(set(common["not_established"]) == set(common["not_established_notes"])
            and len(common["not_established"]) == 10 and all(v is None for v in common["not_established"].values()),
            "Unestablished values must remain null")
    acceptance = item["archived_acceptance"]
    require(acceptance["status"] == "PASS_EXTENSION_RECORDS_ONLY"
            and acceptance["trajectories"] == 24 and acceptance["saved_states"] == 144
            and acceptance["reference_sha256"] == sources[item["source_refs"]["references"]]["sha256"]
            and acceptance["run_receipt_sha256"] == sources[item["source_refs"]["run_receipt"]]["sha256"],
            "Historical acceptance linkage changed")
    for source_id in item["source_refs"].values():
        require(source_id in sources and re.fullmatch(r"[0-9a-f]{64}", sources[source_id]["sha256"]),
                "Missing original source hash")
    return {
        "schema_version": 1, "unit": item["unit"],
        "kind": "REVIEW_RECONSTRUCTION_NOT_ORIGINAL_EFFECTIVE_CONFIGURATION",
        "historical_effective_configuration": {"category": "ABSENT_CONTAINER", "value": None},
        "direct_recorded": group(DIRECT, {"identity": item["recorded"],
            "protocol": common["protocol"], "extension_protocol": common["extension_protocol"],
            "calibrated_gate_reference": item["reference_projection"],
            "model_configured_json_fields": common["model_configured"]},
            {"per_run_original_refs": item["source_refs"], "shared_original_refs": common["source_refs"],
             "reference_json_pointer": "/payload", "model_values_kind": "configured_not_full_library_resolved"}),
        "exact_derived": group(DERIVED, {"explicit_recipe": explicit_recipe(item, common),
                                        "count_projection": item["count_projection"],
                                        "accepted_launch_flags": item["accepted_launch_flags"]},
            {"bound_producer_facts": "inputs/Common.json#/bound_code_facts", "source_locations": "inputs/BoundCodeFacts.json"}),
        "archived_state_validation": group(INHERITED,
            {"optimizer_flags": {f: False for f in ("amsgrad", "maximize", "capturable", "differentiable")},
             "decoupled_weight_decay_acceptance_rule": "group.get('decoupled_weight_decay', True) is True",
             "state_validation_receipt": acceptance},
            {"verifier_source": "campaign/extensions/verify_extension.py", "receipt_ref": common["source_refs"]["historical_validation"],
             "fresh_checkpoint_decode": False}),
        "not_established": group(UNKNOWN, common["not_established"], common["not_established_notes"]),
        "access_and_execution_scope": "Local shareable configuration/aggregate attachment; reconstruction only, not training, inference, public state release, or exhaustive historical environment."}


def safe_name(name):
    p = PurePosixPath(name)
    require(name and "\\" not in name and ":" not in name and not name.startswith("/")
            and all(x not in ("", ".", "..") for x in name.split("/")) and str(p) == name,
            "Unsafe ZIP member path")
    return p


def validated_zip(path):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        require(1 <= len(infos) <= 100 and sum(i.file_size for i in infos) <= 32 * 1024 * 1024,
                "ZIP bounds exceeded")
        seen = set()
        for info in infos:
            safe_name(info.filename)
            require(info.filename.casefold() not in seen, "Duplicate/case-colliding ZIP member")
            seen.add(info.filename.casefold())
            require(not info.is_dir() and not info.flag_bits & 1
                    and not stat.S_ISLNK(info.external_attr >> 16)
                    and info.file_size <= 4 * 1024 * 1024, "Disallowed ZIP member")
        require(archive.testzip() is None, "ZIP CRC failure")
        manifest = json.loads(archive.read("MANIFEST.json"))
        require(set(manifest["members"]) == {i.filename for i in infos} - {"MANIFEST.json"}, "Manifest member inventory mismatch")
        for name, expected in manifest["members"].items():
            require(record(archive.read(name)) == expected, "Member SHA/size mismatch: " + name)
        return {"archive": record(path), "members": len(infos), "member_sha_crc_safe_paths": "PASS",
                "manifest_sha256": hashlib.sha256(archive.read("MANIFEST.json")).hexdigest()}


def extract(path, destination):
    receipt = validated_zip(path)
    require(not destination.exists(), "Extraction destination must be new")
    destination.mkdir(parents=True)
    root = destination.resolve()
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            target = destination.joinpath(*safe_name(info.filename).parts)
            require(target.resolve().is_relative_to(root), "Extraction escapes root")
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(archive.read(info.filename))
    for name, expected in read(destination / "MANIFEST.json")["members"].items():
        require(record(destination / name) == expected, "Extracted member hash mismatch")
    return dict(receipt, extracted_member_sha="PASS")


def replay(root, output=None):
    common = read(root / "inputs/Common.json")
    sources = read(root / "SourceHashes.json")["original_sources"]
    files = sorted((root / "inputs/spectral").glob("*.json"))
    require({p.stem for p in files} == units(), "Expected precisely 24 input projections")
    require({p.stem for p in (root / "recipes").glob("*.json")} == units()
            and {p.stem for p in (root / "recipes").glob("*.yaml")} == units(), "Expected 24 JSON/YAML pairs")
    if output is not None:
        require(not output.exists(), "Replay destination must be new")
        output.mkdir(parents=True)
    digest = []
    for path in files:
        generated = reconstruct(read(path), common, sources)
        expected = read(root / "recipes" / (path.stem + ".json"))
        yaml = read(root / "recipes" / (path.stem + ".yaml"))
        require(generated == expected == yaml, "Reconstructed recipe differs: " + path.stem)
        if output is not None:
            write_new(output / path.name, generated)
        digest.append({"unit": path.stem, "canonical_sha256": hashlib.sha256(canonical(generated)).hexdigest()})
    require(not {"torch", "numpy", "transformers"}.intersection(sys.modules), "Scientific library imported")
    return {"status": "PASS_SAME_RECIPE_RECONSTRUCTION", "units": 24, "json_yaml_pairs": 24,
            "unknowns_remain_null": True, "scientific_libraries_imported": [], "recipe_digests": digest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("replay")
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    p.add_argument("--output", type=Path)
    p = sub.add_parser("check-zip")
    p.add_argument("zip", type=Path)
    p = sub.add_parser("extract")
    p.add_argument("zip", type=Path)
    p.add_argument("destination", type=Path)
    args = parser.parse_args()
    if args.action == "replay":
        result = replay(args.root, args.output)
    elif args.action == "check-zip":
        result = validated_zip(args.zip)
    else:
        result = extract(args.zip, args.destination)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
